package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.lifecycleScope
import com.example.data.FitTrackRepository
import com.example.data.local.FitTrackDatabase
import com.example.ui.MainApp
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val database by lazy { FitTrackDatabase.getDatabase(applicationContext) }
    private val repository by lazy { FitTrackRepository(database.fitTrackDao()) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Initialize default user seed if not present
        lifecycleScope.launch {
            repository.ensureDefaultUser()
        }

        setContent {
            MyApplicationTheme {
                MainApp(repository = repository)
            }
        }
    }
}
