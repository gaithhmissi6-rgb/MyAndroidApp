package com.example.model

data class Exercise(
    val id: String,
    val nameEn: String,
    val nameAr: String,
    val nameFr: String,
    val muscleGroup: String, // "Chest", "Back", "Shoulders", "Biceps", "Triceps", "Forearms", "Quadriceps", "Hamstrings", "Glutes", "Calves", "Abs"
    val difficulty: String, // "Beginner", "Intermediate", "Advanced"
    val defaultSets: Int = 3,
    val defaultReps: Int = 10,
    val defaultRestSeconds: Int = 90,
    val instructionsEn: String,
    val instructionsAr: String,
    val instructionsFr: String,
    val iconEmoji: String = "🏋️"
)

data class WorkoutDay(
    val dayNumber: Int,
    val titleEn: String,
    val titleAr: String,
    val titleFr: String,
    val targetMuscles: List<String>,
    val exercises: List<Exercise>
)

data class WorkoutProgram(
    val id: String,
    val nameEn: String,
    val nameAr: String,
    val nameFr: String,
    val scheduleEn: String,
    val scheduleAr: String,
    val scheduleFr: String,
    val daysPerWeek: Int,
    val difficulty: String,
    val days: List<WorkoutDay>
)

object WorkoutLibrary {

    // 11 Muscle Groups Exercises
    val exercises: List<Exercise> = listOf(
        // Chest
        Exercise(
            id = "barbell_bench_press",
            nameEn = "Barbell Bench Press",
            nameAr = "ضغط الصدر بالبار المستوي",
            nameFr = "Développé Couché à la Barre",
            muscleGroup = "Chest",
            difficulty = "Intermediate",
            defaultSets = 4,
            defaultReps = 8,
            defaultRestSeconds = 120,
            instructionsEn = "Lie on bench, grip bar slightly wider than shoulder width. Lower bar with control to mid-chest, press up explosively.",
            instructionsAr = "استلقِ على المقعد، امسك البار بقبضة أوسع قليلاً من الكتفين، انزل بالبار ببطء لمنتصف الصدر، ثم ادفع للأعلى بقوة.",
            instructionsFr = "Allongé sur le banc, descendez la barre au milieu de la poitrine avec contrôle, puis poussez vigoureusement.",
            iconEmoji = "🏋️‍♂️"
        ),
        Exercise(
            id = "incline_dumbbell_press",
            nameEn = "Incline Dumbbell Press",
            nameAr = "ضغط الصدر العالي بالدمبلز",
            nameFr = "Développé Incliné aux Haltères",
            muscleGroup = "Chest",
            difficulty = "Beginner",
            defaultSets = 3,
            defaultReps = 10,
            defaultRestSeconds = 90,
            instructionsEn = "Set bench at 30-45 degrees. Press dumbbells up over upper chest, squeeze pecs at the top.",
            instructionsAr = "اضبط المقعد بزاوية 30-45 درجة. ادفع الدمبلز للأعلى فوق الجزء العلوي للصدر واعتصر العضلة في القمة.",
            instructionsFr = "Banc incliné à 30-45°, poussez les haltères au-dessus du haut de poitrine.",
            iconEmoji = "💪"
        ),

        // Back
        Exercise(
            id = "barbell_deadlift",
            nameEn = "Conventional Deadlift",
            nameAr = "الرفعة الميتة بالبار (ديدليفت)",
            nameFr = "Soulevé de Terre Conventionnel",
            muscleGroup = "Back",
            difficulty = "Advanced",
            defaultSets = 3,
            defaultReps = 5,
            defaultRestSeconds = 180,
            instructionsEn = "Stand mid-foot under bar. Hinge at hips, grip bar, keep spine neutral, push floor away through heels.",
            instructionsAr = "قف بمنتصف القدم تحت البار. انحنِ من الوركين، حافظ على استقامة الظهر، وادفع الأرض بكعبيك للوقوف.",
            instructionsFr = "Pieds sous la barre, dos droit, engagez les fessiers et poussez avec les talons.",
            iconEmoji = "⚡"
        ),
        Exercise(
            id = "lat_pulldown",
            nameEn = "Lat Pulldown (Cable)",
            nameAr = "سحب الكيبل لأسفل لعضلات اللاتس",
            nameFr = "Tirage Vertical Poitrine",
            muscleGroup = "Back",
            difficulty = "Beginner",
            defaultSets = 4,
            defaultReps = 12,
            defaultRestSeconds = 75,
            instructionsEn = "Grip bar wide, pull down to upper chest while depressing shoulder blades. Control the ascent.",
            instructionsAr = "امسك البار بقبضة عريضة، اسحب لأسفل حتى أعلى الصدر مع عصر لوحي الكتف، وعد ببطء.",
            instructionsFr = "Tirez la barre vers le haut des pectoraux en resserrant les omoplates.",
            iconEmoji = "🏹"
        ),

        // Shoulders
        Exercise(
            id = "overhead_shoulder_press",
            nameEn = "Standing Overhead Press",
            nameAr = "ضغط الأكتاف بالبار واقفاً (OHP)",
            nameFr = "Développé Militaire Debout",
            muscleGroup = "Shoulders",
            difficulty = "Intermediate",
            defaultSets = 4,
            defaultReps = 8,
            defaultRestSeconds = 90,
            instructionsEn = "Bar at collarbone, brace core and glutes, press straight overhead locking out arms with head through.",
            instructionsAr = "البار عند الترقوة، شد عضلات البطن والمؤخرة، وادفع البار عمودياً فوق رأسك بالكامل.",
            instructionsFr = "Barre aux clavicules, gainez le tronc et poussez vers le haut au-dessus de la tête.",
            iconEmoji = "🛡️"
        ),
        Exercise(
            id = "lateral_raises",
            nameEn = "Dumbbell Lateral Raises",
            nameAr = "رفرفة جانبية بالدمبلز للأكتاف",
            nameFr = "Élévations Latérales aux Haltères",
            muscleGroup = "Shoulders",
            difficulty = "Beginner",
            defaultSets = 4,
            defaultReps = 15,
            defaultRestSeconds = 60,
            instructionsEn = "Slight bend in elbows, raise dumbbells to side up to shoulder height, lead with elbows.",
            instructionsAr = "اثنِ الكوعين قليلاً، ارفع الدمبلز جانباً حتى مستوى الكتف مع التركيز على الكوع كدليل.",
            instructionsFr = "Montez les haltères sur les côtés jusqu'à hauteur des épaules, coudes légèrement fléchis.",
            iconEmoji = "🦅"
        ),

        // Biceps
        Exercise(
            id = "barbell_bicep_curl",
            nameEn = "Barbell Bicep Curl",
            nameAr = "مرجحة البايسبس بالبار",
            nameFr = "Curl Biceps à la Barre",
            muscleGroup = "Biceps",
            difficulty = "Beginner",
            defaultSets = 3,
            defaultReps = 10,
            defaultRestSeconds = 60,
            instructionsEn = "Elbows pinned to sides, curl barbell up focusing on bicep contraction, lower with 2-second eccentric.",
            instructionsAr = "ثبّت الكوعين بجانب الجذع، ارفع البار مع التركيز على عصر البايسبس، وانزل بهدوء.",
            instructionsFr = "Coudes serrés au corps, levez la barre en contractant les biceps à fond.",
            iconEmoji = "💥"
        ),

        // Triceps
        Exercise(
            id = "cable_tricep_pushdown",
            nameEn = "Cable Tricep Pushdown",
            nameAr = "دفع الكيبل لأسفل للترايسبس",
            nameFr = "Extension Triceps à la Poulie",
            muscleGroup = "Triceps",
            difficulty = "Beginner",
            defaultSets = 4,
            defaultReps = 12,
            defaultRestSeconds = 60,
            instructionsEn = "Keep elbows tight to ribs, push rope/bar down until elbows are fully locked, squeeze triceps.",
            instructionsAr = "ثبت الكوعين بجانب الأضلاع، ادفع الكيبل لأسفل حتى فرد الذراع بالكامل واعتصر الترايسبس.",
            instructionsFr = "Coudes immobiles le long du buste, étendez les bras vers le bas.",
            iconEmoji = "⚡"
        ),

        // Forearms
        Exercise(
            id = "wrist_curls",
            nameEn = "Dumbbell Wrist Curls",
            nameAr = "ثني المعصم بالدمبل لعضلات الساعد",
            nameFr = "Curl Poignets aux Haltères",
            muscleGroup = "Forearms",
            difficulty = "Beginner",
            defaultSets = 3,
            defaultReps = 15,
            defaultRestSeconds = 45,
            instructionsEn = "Rest forearms on bench or knees, curl wrists upward, pause, then slowly lower.",
            instructionsAr = "اسند الساعدين على المقعد، ارفع المعصم للأعلى بالدمبل، ثم انزل ببطء لتحفيز الساعد.",
            instructionsFr = "Avant-bras posés sur le banc, fléchissez les poignets vers le haut.",
            iconEmoji = "✊"
        ),

        // Quadriceps
        Exercise(
            id = "barbell_back_squat",
            nameEn = "Barbell Back Squat",
            nameAr = "السكوات الخلفي بالبار (القرفصاء)",
            nameFr = "Squat Arrière à la Barre",
            muscleGroup = "Quadriceps",
            difficulty = "Intermediate",
            defaultSets = 4,
            defaultReps = 8,
            defaultRestSeconds = 120,
            instructionsEn = "Bar across upper traps, feet shoulder-width. Sit back and down below parallel, drive up through mid-foot.",
            instructionsAr = "ضع البار على أعلى الظهر، باعد القدمين بعرض الكتف، انزل حتى يتوازى الفخذان مع الأرض، ثم ادفع للأعلى.",
            instructionsFr = "Pieds largeur d'épaules, descendez sous la parallèle, poussez fort avec les cuisses.",
            iconEmoji = "🦵"
        ),

        // Hamstrings
        Exercise(
            id = "romanian_deadlift",
            nameEn = "Romanian Deadlift (RDL)",
            nameAr = "الديدليفت الروماني لأوتار الركبة",
            nameFr = "Soulevé de Terre Roumain (RDL)",
            muscleGroup = "Hamstrings",
            difficulty = "Intermediate",
            defaultSets = 3,
            defaultReps = 10,
            defaultRestSeconds = 90,
            instructionsEn = "Slight knee bend, push hips backwards while bar skims legs until deep stretch in hamstrings.",
            instructionsAr = "ثني طفيف بالركبتين، ادفع الحوض للخلف والبار ملامس للساق حتى تشعر بتمدد قوي في أوتار الركبة.",
            instructionsFr = "Genoux légèrement fléchis, poussez les hanches vers l'arrière jusqu'à l'étirement des ischio-jambiers.",
            iconEmoji = "🔥"
        ),

        // Glutes
        Exercise(
            id = "barbell_hip_thrust",
            nameEn = "Barbell Hip Thrust",
            nameAr = "رفع الحوض بالبار لعضلات الجلوتس",
            nameFr = "Hip Thrust à la Barre",
            muscleGroup = "Glutes",
            difficulty = "Intermediate",
            defaultSets = 4,
            defaultReps = 10,
            defaultRestSeconds = 90,
            instructionsEn = "Upper back against bench, bar padded on hips. Drive through heels to full hip extension, squeeze glutes at top.",
            instructionsAr = "أسند أعلى الظهر على المقعد، ضع البار على الحوض، ادفع بكعبيك للأعلى حتى استقامة الحوض واعتصر الجلوتس.",
            instructionsFr = "Haut du dos calé sur le banc, poussez dans les talons jusqu'à l'extension complète des hanches.",
            iconEmoji = "🍑"
        ),

        // Calves
        Exercise(
            id = "standing_calf_raise",
            nameEn = "Standing Calf Raises",
            nameAr = "رفع السمانة واقفاً",
            nameFr = "Mollets Debout",
            muscleGroup = "Calves",
            difficulty = "Beginner",
            defaultSets = 4,
            defaultReps = 15,
            defaultRestSeconds = 45,
            instructionsEn = "Balls of feet on edge of platform. Lower heels for deep calf stretch, push onto toes with 1s peak contraction.",
            instructionsAr = "قف بمشط القدم على حافة منصة، انزل بالكعبين لأقصى تمدد، ثم ارتفع على أطراف الأصابع واعتصر ثانية.",
            instructionsFr = "Descendez les talons au maximum, puis montez sur la pointe des pieds en contractant.",
            iconEmoji = "🦶"
        ),

        // Abs
        Exercise(
            id = "hanging_leg_raise",
            nameEn = "Hanging Leg / Knee Raises",
            nameAr = "رفع الأرجل معلقاً لعضلات البطن",
            nameFr = "Relevé de Jambes Suspendu",
            muscleGroup = "Abs",
            difficulty = "Intermediate",
            defaultSets = 3,
            defaultReps = 12,
            defaultRestSeconds = 60,
            instructionsEn = "Hang from pull-up bar, tuck pelvis and raise legs or knees to 90 degrees or chest without swinging.",
            instructionsAr = "تعلق بعقلة السحب، ارفع ركبتيك أو رجليك لأعلى نحو الصدر بالتركيز على عضلات البطن السفلية.",
            instructionsFr = "Suspendu à la barre fixe, montez les jambes ou genoux sans balancer le corps.",
            iconEmoji = "🛡️"
        )
    )

    // Complete Workout Programs
    val programs: List<WorkoutProgram> = listOf(
        // Push Pull Legs (PPL)
        WorkoutProgram(
            id = "ppl",
            nameEn = "Push Pull Legs (PPL)",
            nameAr = "دفع، سحب، أرجل (PPL)",
            nameFr = "Push Pull Legs (PPL)",
            scheduleEn = "3 to 6 Days / Week (Optimal Hypertrophy)",
            scheduleAr = "3 إلى 6 أيام في الأسبوع (أفضل جدول لتضخيم العضلات)",
            scheduleFr = "3 à 6 Jours / Semaine (Hypertrophie Optimale)",
            daysPerWeek = 6,
            difficulty = "Intermediate",
            days = listOf(
                WorkoutDay(
                    dayNumber = 1,
                    titleEn = "Push (Chest, Shoulders, Triceps)",
                    titleAr = "يوم الدفع (الصدر، الأكتاف، الترايسبس)",
                    titleFr = "Jour Push (Pectoraux, Épaules, Triceps)",
                    targetMuscles = listOf("Chest", "Shoulders", "Triceps"),
                    exercises = listOf(
                        exercises.first { it.id == "barbell_bench_press" },
                        exercises.first { it.id == "incline_dumbbell_press" },
                        exercises.first { it.id == "overhead_shoulder_press" },
                        exercises.first { it.id == "lateral_raises" },
                        exercises.first { it.id == "cable_tricep_pushdown" }
                    )
                ),
                WorkoutDay(
                    dayNumber = 2,
                    titleEn = "Pull (Back, Biceps, Forearms)",
                    titleAr = "يوم السحب (الظهر، البايسبس، السواعد)",
                    titleFr = "Jour Pull (Dos, Biceps, Avant-bras)",
                    targetMuscles = listOf("Back", "Biceps", "Forearms"),
                    exercises = listOf(
                        exercises.first { it.id == "barbell_deadlift" },
                        exercises.first { it.id == "lat_pulldown" },
                        exercises.first { it.id == "barbell_bicep_curl" },
                        exercises.first { it.id == "wrist_curls" }
                    )
                ),
                WorkoutDay(
                    dayNumber = 3,
                    titleEn = "Legs & Abs (Quads, Hamstrings, Glutes, Calves, Abs)",
                    titleAr = "يوم الأرجل والبطن (الفخذ، السمانة، البطن)",
                    titleFr = "Jour Jambes & Abdos",
                    targetMuscles = listOf("Quadriceps", "Hamstrings", "Glutes", "Calves", "Abs"),
                    exercises = listOf(
                        exercises.first { it.id == "barbell_back_squat" },
                        exercises.first { it.id == "romanian_deadlift" },
                        exercises.first { it.id == "barbell_hip_thrust" },
                        exercises.first { it.id == "standing_calf_raise" },
                        exercises.first { it.id == "hanging_leg_raise" }
                    )
                )
            )
        ),

        // Upper Lower
        WorkoutProgram(
            id = "upper_lower",
            nameEn = "Upper Lower Split",
            nameAr = "تقسيم علوي / سفلي (Upper Lower)",
            nameFr = "Haut / Bas du Corps (Upper Lower)",
            scheduleEn = "4 Days / Week (Great Strength & Balance)",
            scheduleAr = "4 أيام في الأسبوع (توازن ممتاز وقوة بدنية)",
            scheduleFr = "4 Jours / Semaine (Force et Récupération)",
            daysPerWeek = 4,
            difficulty = "Intermediate",
            days = listOf(
                WorkoutDay(
                    dayNumber = 1,
                    titleEn = "Upper Body (Chest, Back, Arms)",
                    titleAr = "الجزء العلوي (الصدر، الظهر، الذراعين)",
                    titleFr = "Haut du Corps",
                    targetMuscles = listOf("Chest", "Back", "Shoulders", "Biceps", "Triceps"),
                    exercises = listOf(
                        exercises.first { it.id == "barbell_bench_press" },
                        exercises.first { it.id == "lat_pulldown" },
                        exercises.first { it.id == "overhead_shoulder_press" },
                        exercises.first { it.id == "barbell_bicep_curl" },
                        exercises.first { it.id == "cable_tricep_pushdown" }
                    )
                ),
                WorkoutDay(
                    dayNumber = 2,
                    titleEn = "Lower Body & Core (Quads, Hamstrings, Calves, Abs)",
                    titleAr = "الجزء السفلي والبطن (الأرجل والسمانة والبطن)",
                    titleFr = "Bas du Corps & Abdos",
                    targetMuscles = listOf("Quadriceps", "Hamstrings", "Glutes", "Calves", "Abs"),
                    exercises = listOf(
                        exercises.first { it.id == "barbell_back_squat" },
                        exercises.first { it.id == "romanian_deadlift" },
                        exercises.first { it.id == "standing_calf_raise" },
                        exercises.first { it.id == "hanging_leg_raise" }
                    )
                )
            )
        ),

        // Full Body
        WorkoutProgram(
            id = "full_body",
            nameEn = "Full Body Workout",
            nameAr = "تمرين كامل الجسم (Full Body)",
            nameFr = "Entraînement Corps Entier (Full Body)",
            scheduleEn = "3 Days / Week (Ideal for Busy Lifestyles & Beginners)",
            scheduleAr = "3 أيام في الأسبوع (مثالي للمبتدئين وأصحاب الوقت المحدود)",
            scheduleFr = "3 Jours / Semaine (Idéal Débutants & Vies Actives)",
            daysPerWeek = 3,
            difficulty = "Beginner",
            days = listOf(
                WorkoutDay(
                    dayNumber = 1,
                    titleEn = "Full Body Session A",
                    titleAr = "جلسة كامل الجسم (أ)",
                    titleFr = "Séance Full Body A",
                    targetMuscles = listOf("Quadriceps", "Chest", "Back", "Shoulders", "Abs"),
                    exercises = listOf(
                        exercises.first { it.id == "barbell_back_squat" },
                        exercises.first { it.id == "barbell_bench_press" },
                        exercises.first { it.id == "lat_pulldown" },
                        exercises.first { it.id == "lateral_raises" },
                        exercises.first { it.id == "hanging_leg_raise" }
                    )
                ),
                WorkoutDay(
                    dayNumber = 2,
                    titleEn = "Full Body Session B",
                    titleAr = "جلسة كامل الجسم (ب)",
                    titleFr = "Séance Full Body B",
                    targetMuscles = listOf("Back", "Hamstrings", "Chest", "Arms"),
                    exercises = listOf(
                        exercises.first { it.id == "barbell_deadlift" },
                        exercises.first { it.id == "incline_dumbbell_press" },
                        exercises.first { it.id == "overhead_shoulder_press" },
                        exercises.first { it.id == "barbell_bicep_curl" },
                        exercises.first { it.id == "cable_tricep_pushdown" }
                    )
                )
            )
        ),

        // Bro Split
        WorkoutProgram(
            id = "bro_split",
            nameEn = "Classic Bro Split (Body Part)",
            nameAr = "التقسيم الكلاسيكي (Bro Split - عضلة يومياً)",
            nameFr = "Split Traditionnel (Un Muscle par Jour)",
            scheduleEn = "5 Days / Week (Maximum Muscle Focus)",
            scheduleAr = "5 أيام في الأسبوع (تركيز أقصى على كل عضلة منفردة)",
            scheduleFr = "5 Jours / Semaine (Focus Musculaire Maximal)",
            daysPerWeek = 5,
            difficulty = "Advanced",
            days = listOf(
                WorkoutDay(
                    dayNumber = 1,
                    titleEn = "Chest Day",
                    titleAr = "يوم الصدر",
                    titleFr = "Jour Pectoraux",
                    targetMuscles = listOf("Chest"),
                    exercises = listOf(
                        exercises.first { it.id == "barbell_bench_press" },
                        exercises.first { it.id == "incline_dumbbell_press" }
                    )
                ),
                WorkoutDay(
                    dayNumber = 2,
                    titleEn = "Back Day",
                    titleAr = "يوم الظهر",
                    titleFr = "Jour Dos",
                    targetMuscles = listOf("Back"),
                    exercises = listOf(
                        exercises.first { it.id == "barbell_deadlift" },
                        exercises.first { it.id == "lat_pulldown" }
                    )
                ),
                WorkoutDay(
                    dayNumber = 3,
                    titleEn = "Shoulders Day",
                    titleAr = "يوم الأكتاف",
                    titleFr = "Jour Épaules",
                    targetMuscles = listOf("Shoulders"),
                    exercises = listOf(
                        exercises.first { it.id == "overhead_shoulder_press" },
                        exercises.first { it.id == "lateral_raises" }
                    )
                ),
                WorkoutDay(
                    dayNumber = 4,
                    titleEn = "Legs Day",
                    titleAr = "يوم الأرجل",
                    titleFr = "Jour Jambes",
                    targetMuscles = listOf("Quadriceps", "Hamstrings", "Calves"),
                    exercises = listOf(
                        exercises.first { it.id == "barbell_back_squat" },
                        exercises.first { it.id == "romanian_deadlift" },
                        exercises.first { it.id == "standing_calf_raise" }
                    )
                ),
                WorkoutDay(
                    dayNumber = 5,
                    titleEn = "Arms & Abs Day",
                    titleAr = "يوم الذراعين والبطن",
                    titleFr = "Jour Bras & Abdos",
                    targetMuscles = listOf("Biceps", "Triceps", "Abs"),
                    exercises = listOf(
                        exercises.first { it.id == "barbell_bicep_curl" },
                        exercises.first { it.id == "cable_tricep_pushdown" },
                        exercises.first { it.id == "wrist_curls" },
                        exercises.first { it.id == "hanging_leg_raise" }
                    )
                )
            )
        )
    )
}
