package com.example.model

data class FoodItem(
    val id: String,
    val nameEn: String,
    val nameAr: String,
    val nameFr: String,
    val category: String, // "Tunisian", "Protein", "Carbs", "Healthy Fats", "Snacks", "Drinks"
    val defaultServingGrams: Float,
    val caloriesPer100g: Int,
    val proteinPer100g: Float,
    val carbsPer100g: Float,
    val fatPer100g: Float,
    val iconEmoji: String
) {
    fun calculateCalories(servingGrams: Float): Int =
        ((caloriesPer100g * servingGrams) / 100f).toInt()

    fun calculateProtein(servingGrams: Float): Float =
        (proteinPer100g * servingGrams) / 100f

    fun calculateCarbs(servingGrams: Float): Float =
        (carbsPer100g * servingGrams) / 100f

    fun calculateFat(servingGrams: Float): Float =
        (fatPer100g * servingGrams) / 100f
}

object FoodCatalog {
    val items: List<FoodItem> = listOf(
        // Traditional Tunisian & Arabic Foods
        FoodItem(
            id = "couscous",
            nameEn = "Tunisian Couscous with Meat",
            nameAr = "كسكسي تونسي باللحم والخضار",
            nameFr = "Couscous Tunisien à la Viande",
            category = "Tunisian",
            defaultServingGrams = 350f,
            caloriesPer100g = 185,
            proteinPer100g = 8.5f,
            carbsPer100g = 26.0f,
            fatPer100g = 5.2f,
            iconEmoji = "🍲"
        ),
        FoodItem(
            id = "brik",
            nameEn = "Tunisian Brik with Egg & Tuna",
            nameAr = "بريك تونسي بالعظمة والتن",
            nameFr = "Brik Tunisienne à l'œuf et Thon",
            category = "Tunisian",
            defaultServingGrams = 120f,
            caloriesPer100g = 245,
            proteinPer100g = 13.0f,
            carbsPer100g = 18.0f,
            fatPer100g = 14.5f,
            iconEmoji = "🥟"
        ),
        FoodItem(
            id = "ojja",
            nameEn = "Tunisian Ojja with Merguez",
            nameAr = "عجة تونسية بالمرقاز والبيض",
            nameFr = "Ojja Tunisienne aux Merguez",
            category = "Tunisian",
            defaultServingGrams = 280f,
            caloriesPer100g = 175,
            proteinPer100g = 11.2f,
            carbsPer100g = 6.4f,
            fatPer100g = 12.0f,
            iconEmoji = "🍳"
        ),
        FoodItem(
            id = "lablabi",
            nameEn = "Tunisian Lablabi (Chickpea Soup)",
            nameAr = "لبلابي تونسي بالكمون وزيت الزيتون",
            nameFr = "Lablabi Tunisien aux Pois Chiches",
            category = "Tunisian",
            defaultServingGrams = 350f,
            caloriesPer100g = 140,
            proteinPer100g = 7.8f,
            carbsPer100g = 21.5f,
            fatPer100g = 3.6f,
            iconEmoji = "🥣"
        ),
        FoodItem(
            id = "makrouna",
            nameEn = "Tunisian Spicy Makrouna Pasta",
            nameAr = "مقرونة تونسية جارية بالدجاج",
            nameFr = "Makrouna Tunisienne Piquante",
            category = "Tunisian",
            defaultServingGrams = 320f,
            caloriesPer100g = 168,
            proteinPer100g = 9.4f,
            carbsPer100g = 24.0f,
            fatPer100g = 4.2f,
            iconEmoji = "🍝"
        ),
        FoodItem(
            id = "shakshuka",
            nameEn = "Shakshuka with Eggs",
            nameAr = "شكشوكة بالبيض والفلفل",
            nameFr = "Chakchouka aux Œufs",
            category = "Tunisian",
            defaultServingGrams = 250f,
            caloriesPer100g = 115,
            proteinPer100g = 6.5f,
            carbsPer100g = 7.0f,
            fatPer100g = 7.2f,
            iconEmoji = "🥘"
        ),
        FoodItem(
            id = "dates",
            nameEn = "Tunisian Deglet Nour Dates",
            nameAr = "دقلة النور تونسية (تمر)",
            nameFr = "Dattes Deglet Nour",
            category = "Tunisian",
            defaultServingGrams = 60f,
            caloriesPer100g = 282,
            proteinPer100g = 2.5f,
            carbsPer100g = 75.0f,
            fatPer100g = 0.4f,
            iconEmoji = "🌴"
        ),

        // Traditional Emirati & Gulf Delicacies
        FoodItem(
            id = "emirati_machboos",
            nameEn = "Emirati Chicken Machboos",
            nameAr = "مجبوس دجاج إماراتي بالزعفران واللومي",
            nameFr = "Machboos Émirati au Poulet",
            category = "Emirati",
            defaultServingGrams = 350f,
            caloriesPer100g = 195,
            proteinPer100g = 12.5f,
            carbsPer100g = 23.0f,
            fatPer100g = 6.2f,
            iconEmoji = "🍗"
        ),
        FoodItem(
            id = "emirati_harees",
            nameEn = "Emirati Meat Harees",
            nameAr = "هريس إماراتي باللحم والسمن البلدي",
            nameFr = "Harees Émirati à la Viande",
            category = "Emirati",
            defaultServingGrams = 300f,
            caloriesPer100g = 160,
            proteinPer100g = 11.0f,
            carbsPer100g = 19.5f,
            fatPer100g = 4.5f,
            iconEmoji = "🥣"
        ),
        FoodItem(
            id = "emirati_saloona",
            nameEn = "Emirati Chicken Saloona Stew",
            nameAr = "صالونة دجاج وخضار إماراتية بالبهارات",
            nameFr = "Saloona Émirati aux Légumes et Poulet",
            category = "Emirati",
            defaultServingGrams = 320f,
            caloriesPer100g = 125,
            proteinPer100g = 9.8f,
            carbsPer100g = 8.5f,
            fatPer100g = 5.6f,
            iconEmoji = "🍲"
        ),
        FoodItem(
            id = "emirati_balaleet",
            nameEn = "Emirati Balaleet with Omelette",
            nameAr = "بلاليط إماراتي بالزعفران والهيل والبيض",
            nameFr = "Balaleet Émirati au Safran et Œuf",
            category = "Emirati",
            defaultServingGrams = 200f,
            caloriesPer100g = 190,
            proteinPer100g = 6.0f,
            carbsPer100g = 32.0f,
            fatPer100g = 4.8f,
            iconEmoji = "🍳"
        ),
        FoodItem(
            id = "emirati_luqaimat",
            nameEn = "Emirati Luqaimat with Date Syrup",
            nameAr = "لقيمات إماراتية مقرمشة بدبس التمر والسمسم",
            nameFr = "Luqaimat Émirati au Sirop de Datte",
            category = "Emirati",
            defaultServingGrams = 120f,
            caloriesPer100g = 310,
            proteinPer100g = 4.5f,
            carbsPer100g = 52.0f,
            fatPer100g = 9.8f,
            iconEmoji = "🍯"
        ),
        FoodItem(
            id = "camel_milk",
            nameEn = "Fresh Camel Milk",
            nameAr = "حليب نوق إماراتي طازج (إبل)",
            nameFr = "Lait de Chamelle Frais",
            category = "Emirati",
            defaultServingGrams = 250f,
            caloriesPer100g = 53,
            proteinPer100g = 3.4f,
            carbsPer100g = 4.4f,
            fatPer100g = 2.5f,
            iconEmoji = "🥛"
        ),

        // International High-Protein & Fitness Staples
        FoodItem(
            id = "chicken_breast",
            nameEn = "Grilled Chicken Breast",
            nameAr = "صدر دجاج مشوي",
            nameFr = "Blanc de Poulet Grillé",
            category = "Protein",
            defaultServingGrams = 150f,
            caloriesPer100g = 165,
            proteinPer100g = 31.0f,
            carbsPer100g = 0.0f,
            fatPer100g = 3.6f,
            iconEmoji = "🍗"
        ),
        FoodItem(
            id = "whole_egg",
            nameEn = "Boiled or Fried Eggs",
            nameAr = "بيض مسلوق أو مقلي",
            nameFr = "Œufs Entiers",
            category = "Protein",
            defaultServingGrams = 100f, // ~2 eggs
            caloriesPer100g = 143,
            proteinPer100g = 12.6f,
            carbsPer100g = 0.7f,
            fatPer100g = 9.5f,
            iconEmoji = "🥚"
        ),
        FoodItem(
            id = "salmon",
            nameEn = "Grilled Atlantic Salmon",
            nameAr = "سمك السلمون المشوي",
            nameFr = "Saumon Grillé",
            category = "Protein",
            defaultServingGrams = 150f,
            caloriesPer100g = 208,
            proteinPer100g = 20.4f,
            carbsPer100g = 0.0f,
            fatPer100g = 13.4f,
            iconEmoji = "🐟"
        ),
        FoodItem(
            id = "tuna_canned",
            nameEn = "Canned Tuna in Natural Water",
            nameAr = "تونة معلبة طبيعية",
            nameFr = "Thon au Naturel",
            category = "Protein",
            defaultServingGrams = 120f,
            caloriesPer100g = 116,
            proteinPer100g = 26.0f,
            carbsPer100g = 0.0f,
            fatPer100g = 1.0f,
            iconEmoji = "🥫"
        ),
        FoodItem(
            id = "beef_steak",
            nameEn = "Lean Beef Steak",
            nameAr = "لحم بقري هبرة مشوي",
            nameFr = "Steak de Bœuf Maigre",
            category = "Protein",
            defaultServingGrams = 180f,
            caloriesPer100g = 215,
            proteinPer100g = 26.0f,
            carbsPer100g = 0.0f,
            fatPer100g = 12.0f,
            iconEmoji = "🥩"
        ),
        FoodItem(
            id = "whey_protein",
            nameEn = "Whey Protein Shake",
            nameAr = "مخفوق بروتين مصل اللبن (واي)",
            nameFr = "Shake de Whey Protéine",
            category = "Protein",
            defaultServingGrams = 35f,
            caloriesPer100g = 390,
            proteinPer100g = 78.0f,
            carbsPer100g = 8.0f,
            fatPer100g = 4.5f,
            iconEmoji = "🥤"
        ),
        FoodItem(
            id = "greek_yogurt",
            nameEn = "Greek Yogurt (0% Fat)",
            nameAr = "زبادي يوناني خالي الدسم",
            nameFr = "Yaourt Grec 0%",
            category = "Protein",
            defaultServingGrams = 170f,
            caloriesPer100g = 59,
            proteinPer100g = 10.0f,
            carbsPer100g = 3.6f,
            fatPer100g = 0.4f,
            iconEmoji = "🥛"
        ),

        // Healthy Carbs
        FoodItem(
            id = "white_rice",
            nameEn = "Cooked Basmati Rice",
            nameAr = "أرز بسمتي مطبوخ",
            nameFr = "Riz Basmati Cuit",
            category = "Carbs",
            defaultServingGrams = 200f,
            caloriesPer100g = 130,
            proteinPer100g = 2.7f,
            carbsPer100g = 28.2f,
            fatPer100g = 0.3f,
            iconEmoji = "🍚"
        ),
        FoodItem(
            id = "rolled_oats",
            nameEn = "Rolled Oats Oatmeal",
            nameAr = "شوفان حبوب كاملة",
            nameFr = "Flocons d'Avoine",
            category = "Carbs",
            defaultServingGrams = 60f,
            caloriesPer100g = 389,
            proteinPer100g = 16.9f,
            carbsPer100g = 66.3f,
            fatPer100g = 6.9f,
            iconEmoji = "🌾"
        ),
        FoodItem(
            id = "sweet_potato",
            nameEn = "Baked Sweet Potato",
            nameAr = "بطاطا حلوة مشوية",
            nameFr = "Patate Douce Rôtie",
            category = "Carbs",
            defaultServingGrams = 200f,
            caloriesPer100g = 86,
            proteinPer100g = 1.6f,
            carbsPer100g = 20.1f,
            fatPer100g = 0.1f,
            iconEmoji = "🍠"
        ),
        FoodItem(
            id = "banana",
            nameEn = "Fresh Banana",
            nameAr = "موز طازج",
            nameFr = "Banane Fraîche",
            category = "Carbs",
            defaultServingGrams = 120f,
            caloriesPer100g = 89,
            proteinPer100g = 1.1f,
            carbsPer100g = 22.8f,
            fatPer100g = 0.3f,
            iconEmoji = "🍌"
        ),
        FoodItem(
            id = "whole_milk",
            nameEn = "Whole Milk (Cow)",
            nameAr = "حليب بقر كامل الدسم",
            nameFr = "Lait Entier",
            category = "Drinks",
            defaultServingGrams = 250f, // 250 ml
            caloriesPer100g = 62,
            proteinPer100g = 3.2f,
            carbsPer100g = 4.8f,
            fatPer100g = 3.5f,
            iconEmoji = "🥛"
        ),
        FoodItem(
            id = "avocado",
            nameEn = "Fresh Avocado",
            nameAr = "أفوكادو طازج",
            nameFr = "Avocat Frais",
            category = "Healthy Fats",
            defaultServingGrams = 100f,
            caloriesPer100g = 160,
            proteinPer100g = 2.0f,
            carbsPer100g = 8.5f,
            fatPer100g = 14.7f,
            iconEmoji = "🥑"
        ),
        FoodItem(
            id = "olive_oil",
            nameEn = "Extra Virgin Olive Oil",
            nameAr = "زيت زيتون بكر ممتاز",
            nameFr = "Huile d'Olive Vierge",
            category = "Healthy Fats",
            defaultServingGrams = 15f,
            caloriesPer100g = 884,
            proteinPer100g = 0.0f,
            carbsPer100g = 0.0f,
            fatPer100g = 100.0f,
            iconEmoji = "🫒"
        ),
        FoodItem(
            id = "almonds",
            nameEn = "Raw Almonds",
            nameAr = "لوز نيء",
            nameFr = "Amandes Crues",
            category = "Snacks",
            defaultServingGrams = 30f,
            caloriesPer100g = 579,
            proteinPer100g = 21.2f,
            carbsPer100g = 21.6f,
            fatPer100g = 49.9f,
            iconEmoji = "🥜"
        )
    )

    fun search(query: String): List<FoodItem> {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return items
        return items.filter { item ->
            item.nameEn.lowercase().contains(q) ||
            item.nameAr.contains(q) ||
            item.nameFr.lowercase().contains(q) ||
            item.category.lowercase().contains(q)
        }
    }

    fun findBestMatch(name: String): FoodItem? {
        val clean = name.trim().lowercase()
        return items.firstOrNull {
            it.id == clean ||
            it.nameEn.lowercase().contains(clean) ||
            it.nameAr.contains(clean) ||
            it.nameFr.lowercase().contains(clean)
        }
    }
}
