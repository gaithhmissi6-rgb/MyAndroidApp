package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// FITTRACK Signature Brand Colors
val LimeGreen = Color(0xFFA6FF00)
val LimeGreenDark = Color(0xFF76BD00)
val LimeGreenContainer = Color(0xFF1E3300)
val DarkBackground = Color(0xFF090A0E)
val DarkSurface = Color(0xFF13151D)
val DarkSurfaceElevated = Color(0xFF1B1E29)
val DarkSurfaceHighlight = Color(0xFF262B3A)

// Accent Colors
val AccentCyan = Color(0xFF00E5FF)
val AccentOrange = Color(0xFFFF9100)
val AccentRed = Color(0xFFFF5252)
val AccentPurple = Color(0xFFB388FF)

// Text & Neutral Colors
val TextWhite = Color(0xFFFFFFFF)
val TextLightGray = Color(0xFFE2E8F0)
val TextMutedGray = Color(0xFF94A3B8)
val BorderDark = Color(0xFF272D3D)
