package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.LimeGreen
import com.example.ui.theme.TextMutedGray
import com.example.ui.theme.TextWhite

data class ChartPoint(
    val label: String,
    val value: Float
)

@Composable
fun LineProgressChart(
    title: String,
    points: List<ChartPoint>,
    unit: String = "kg",
    accentColor: Color = LimeGreen,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium.copy(
                        color = TextWhite,
                        fontWeight = FontWeight.Bold
                    )
                )

                if (points.isNotEmpty()) {
                    val latest = points.last().value
                    Text(
                        text = "$latest $unit",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = accentColor,
                            fontWeight = FontWeight.Black
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (points.size < 2) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(120.dp)
                        .background(Color(0xFF161822), RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Log at least 2 entries to see progress trend",
                        style = MaterialTheme.typography.bodySmall.copy(color = TextMutedGray)
                    )
                }
            } else {
                val minVal = points.minOf { it.value } - 1f
                val maxVal = points.maxOf { it.value } + 1f
                val range = if (maxVal - minVal > 0f) maxVal - minVal else 1f

                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp)
                ) {
                    val width = size.width
                    val height = size.height
                    val spacing = width / (points.size - 1)

                    val strokePath = Path()
                    val fillPath = Path()

                    points.forEachIndexed { index, point ->
                        val x = index * spacing
                        val normalized = (point.value - minVal) / range
                        val y = height - (normalized * (height - 30.dp.toPx())) - 15.dp.toPx()

                        if (index == 0) {
                            strokePath.moveTo(x, y)
                            fillPath.moveTo(x, height)
                            fillPath.lineTo(x, y)
                        } else {
                            strokePath.lineTo(x, y)
                            fillPath.lineTo(x, y)
                        }

                        // Draw point circle
                        drawCircle(
                            color = accentColor,
                            radius = 4.dp.toPx(),
                            center = Offset(x, y)
                        )
                        drawCircle(
                            color = Color(0xFF090A0E),
                            radius = 2.dp.toPx(),
                            center = Offset(x, y)
                        )
                    }

                    fillPath.lineTo(width, height)
                    fillPath.close()

                    // Gradient under line
                    drawPath(
                        path = fillPath,
                        brush = Brush.verticalGradient(
                            colors = listOf(
                                accentColor.copy(alpha = 0.25f),
                                Color.Transparent
                            )
                        )
                    )

                    // Line stroke
                    drawPath(
                        path = strokePath,
                        color = accentColor,
                        style = Stroke(
                            width = 3.dp.toPx(),
                            cap = StrokeCap.Round
                        )
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // X-Axis Labels
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    points.forEach { point ->
                        Text(
                            text = point.label,
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = TextMutedGray,
                                fontSize = 10.sp
                            )
                        )
                    }
                }
            }
        }
    }
}
