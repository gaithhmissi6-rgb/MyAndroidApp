package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val FitTrackDarkColorScheme = darkColorScheme(
    primary = LimeGreen,
    onPrimary = DarkBackground,
    primaryContainer = LimeGreenContainer,
    onPrimaryContainer = LimeGreen,
    secondary = AccentCyan,
    onSecondary = DarkBackground,
    secondaryContainer = DarkSurfaceHighlight,
    onSecondaryContainer = AccentCyan,
    tertiary = AccentOrange,
    onTertiary = DarkBackground,
    background = DarkBackground,
    onBackground = TextWhite,
    surface = DarkSurface,
    onSurface = TextWhite,
    surfaceVariant = DarkSurfaceElevated,
    onSurfaceVariant = TextLightGray,
    outline = BorderDark,
    error = AccentRed,
    onError = TextWhite
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = FitTrackDarkColorScheme,
        typography = Typography,
        content = content
    )
}
