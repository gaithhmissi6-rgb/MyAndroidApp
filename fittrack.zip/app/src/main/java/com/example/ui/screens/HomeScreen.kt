package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.DirectionsRun
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.LocalDrink
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.FoodLogEntity
import com.example.data.local.UserProfileEntity
import com.example.data.local.WaterLogEntity
import com.example.localization.AppStrings
import androidx.compose.foundation.Image
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import com.example.R
import com.example.ui.components.CircularMacroRing
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentOrange
import com.example.ui.theme.AccentRed
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.LimeGreen
import com.example.ui.theme.TextLightGray
import com.example.ui.theme.TextMutedGray
import com.example.ui.theme.TextWhite

@Composable
fun HomeScreen(
    userProfile: UserProfileEntity,
    todayFoodLogs: List<FoodLogEntity>,
    todayWaterLog: WaterLogEntity?,
    strings: AppStrings,
    onNavigateToNutrition: () -> Unit,
    onNavigateToWorkouts: () -> Unit,
    onNavigateToCoach: () -> Unit,
    onAddWater: (Int) -> Unit,
    onDeleteFoodLog: (FoodLogEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    val caloriesConsumed = todayFoodLogs.sumOf { it.calories }
    val proteinConsumed = todayFoodLogs.map { it.proteinGrams }.sum()
    val carbsConsumed = todayFoodLogs.map { it.carbsGrams }.sum()
    val fatConsumed = todayFoodLogs.map { it.fatGrams }.sum()
    val waterConsumedMl = todayWaterLog?.amountMl ?: 0

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // High-Quality Fitness Hero Banner
        item {
            Spacer(modifier = Modifier.height(4.dp))
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp),
                shape = RoundedCornerShape(20.dp)
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    Image(
                        painter = painterResource(id = R.drawable.img_fitness_hero),
                        contentDescription = "Fitness Hero Banner",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                    // Dark Gradient scrim
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                androidx.compose.ui.graphics.Brush.horizontalGradient(
                                    colors = listOf(
                                        Color(0xCC090A0E),
                                        Color(0x44090A0E)
                                    )
                                )
                            )
                    )
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "FITTRACK PRO ⚡",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = LimeGreen,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "${strings.greeting}, ${userProfile.name}",
                            style = MaterialTheme.typography.titleLarge.copy(
                                color = TextWhite,
                                fontWeight = FontWeight.Black
                            )
                        )
                        Text(
                            text = "${userProfile.fitnessGoal} • Day Streak 7 🔥",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = TextLightGray
                            )
                        )
                    }
                }
            }
        }

                // Streak Badge
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF1E2812))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(text = "🔥 ", fontSize = 14.sp)
                        Text(
                            text = "7 ${strings.streakDays}",
                            style = MaterialTheme.typography.labelMedium.copy(
                                color = LimeGreen,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                }
            }
        }

        // Circular Calorie & Macro Gauge
        item {
            CircularMacroRing(
                caloriesConsumed = caloriesConsumed,
                calorieGoal = userProfile.dailyCalorieTarget,
                proteinGrams = proteinConsumed,
                proteinGoal = userProfile.dailyProteinTargetG,
                carbsGrams = carbsConsumed,
                carbsGoal = userProfile.dailyCarbsTargetG,
                fatGrams = fatConsumed,
                fatGoal = userProfile.dailyFatTargetG,
                strings = strings
            )
        }

        // Quick Actions Row
        item {
            Text(
                text = strings.quickActions,
                style = MaterialTheme.typography.titleMedium.copy(
                    color = TextWhite,
                    fontWeight = FontWeight.Bold
                )
            )
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                QuickActionCard(
                    title = strings.scanMeal,
                    icon = Icons.Default.CameraAlt,
                    accentColor = LimeGreen,
                    modifier = Modifier.weight(1f),
                    onClick = onNavigateToNutrition
                )
                QuickActionCard(
                    title = strings.logWorkout,
                    icon = Icons.Default.FitnessCenter,
                    accentColor = AccentCyan,
                    modifier = Modifier.weight(1f),
                    onClick = onNavigateToWorkouts
                )
                QuickActionCard(
                    title = strings.askCoach,
                    icon = Icons.Default.Psychology,
                    accentColor = AccentOrange,
                    modifier = Modifier.weight(1f),
                    onClick = onNavigateToCoach
                )
            }
        }

        // Water Hydration Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("water_card"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(AccentCyan.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.WaterDrop,
                                    contentDescription = null,
                                    tint = AccentCyan,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = strings.waterIntake,
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        color = TextWhite,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                                Text(
                                    text = "$waterConsumedMl / ${userProfile.dailyWaterTargetMl} ${strings.mlUnit}",
                                    style = MaterialTheme.typography.bodySmall.copy(color = TextMutedGray)
                                )
                            }
                        }

                        // Quick Water Add Buttons
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(
                                onClick = { onAddWater(250) },
                                modifier = Modifier.testTag("water_add_250")
                            ) {
                                Text("+250ml", color = AccentCyan, fontSize = 12.sp)
                            }
                            OutlinedButton(
                                onClick = { onAddWater(500) },
                                modifier = Modifier.testTag("water_add_500")
                            ) {
                                Text("+500ml", color = AccentCyan, fontSize = 12.sp)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Hydration Progress Bar
                    val waterRatio = (waterConsumedMl.toFloat() / userProfile.dailyWaterTargetMl.toFloat()).coerceIn(0f, 1f)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color(0xFF1E2333))
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(waterRatio)
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(AccentCyan)
                        )
                    }
                }
            }
        }

        // Today's Meals Summary
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Today's Logged Foods",
                    style = MaterialTheme.typography.titleMedium.copy(
                        color = TextWhite,
                        fontWeight = FontWeight.Bold
                    )
                )
                Text(
                    text = "${todayFoodLogs.size} items",
                    style = MaterialTheme.typography.bodySmall.copy(color = LimeGreen)
                )
            }
        }

        if (todayFoodLogs.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "No meals logged yet today.",
                            style = MaterialTheme.typography.bodyMedium.copy(color = TextMutedGray)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedButton(onClick = onNavigateToNutrition) {
                            Text(strings.scanMeal, color = LimeGreen)
                        }
                    }
                }
            }
        } else {
            items(todayFoodLogs) { log ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = log.foodName,
                                style = MaterialTheme.typography.bodyLarge.copy(
                                    color = TextWhite,
                                    fontWeight = FontWeight.SemiBold
                                )
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "${log.mealType} • ${log.amountGramsOrMl.toInt()}g • P: ${log.proteinGrams.toInt()}g | C: ${log.carbsGrams.toInt()}g | F: ${log.fatGrams.toInt()}g",
                                style = MaterialTheme.typography.bodySmall.copy(color = TextMutedGray)
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "${log.calories} kcal",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = LimeGreen,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                            IconButton(onClick = { onDeleteFoodLog(log) }) {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = "Delete",
                                    tint = AccentRed.copy(alpha = 0.7f),
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun QuickActionCard(
    title: String,
    icon: ImageVector,
    accentColor: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(accentColor.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accentColor,
                    modifier = Modifier.size(22.dp)
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.labelMedium.copy(
                    color = TextWhite,
                    fontWeight = FontWeight.SemiBold
                ),
                maxLines = 1
            )
        }
    }
}
