package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.FitTrackRepository
import com.example.data.local.UserProfileEntity
import com.example.localization.FitTrackStrings
import com.example.localization.Language
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.NutritionScreen
import com.example.ui.screens.OnboardingScreen
import com.example.ui.screens.ProfileAndCoachScreen
import com.example.ui.screens.ProgressScreen
import com.example.ui.screens.WorkoutsScreen
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.LimeGreen
import com.example.ui.theme.TextMutedGray
import com.example.ui.theme.TextWhite
import kotlinx.coroutines.launch

@Composable
fun MainApp(
    repository: FitTrackRepository,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()

    val userProfile by repository.userProfile.collectAsState(initial = null)
    val todayFoodLogs by repository.getTodayFoodLogs().collectAsState(initial = emptyList())
    val todayWaterLog by repository.getTodayWaterLog().collectAsState(initial = null)
    val workoutLogs by repository.recentWorkouts.collectAsState(initial = emptyList())
    val measurements by repository.allMeasurements.collectAsState(initial = emptyList())

    // Active language state
    var activeLanguage by remember(userProfile?.selectedLanguage) {
        mutableStateOf(
            if (userProfile != null) Language.fromCode(userProfile!!.selectedLanguage)
            else Language.ENGLISH
        )
    }

    val strings = FitTrackStrings.get(activeLanguage)
    val layoutDirection = if (activeLanguage.isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr

    // 5 Main Navigation Tabs: 0: Home, 1: Nutrition, 2: Workouts, 3: Progress, 4: Profile
    var selectedTab by remember { mutableIntStateOf(0) }
    var isEditingProfileInApp by remember { mutableStateOf(false) }

    CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
        val profile = userProfile
        if (profile == null || !profile.isOnboarded || isEditingProfileInApp) {
            OnboardingScreen(
                initialProfile = profile ?: UserProfileEntity(),
                currentLanguage = activeLanguage,
                onLanguageSelected = { lang ->
                    activeLanguage = lang
                },
                onFinishOnboarding = { updatedProfile ->
                    coroutineScope.launch {
                        repository.saveUserProfile(updatedProfile)
                        isEditingProfileInApp = false
                    }
                }
            )
        } else {
            Scaffold(
                modifier = modifier.fillMaxSize(),
                containerColor = DarkBackground,
                bottomBar = {
                    NavigationBar(
                        containerColor = DarkSurfaceElevated,
                        contentColor = TextWhite,
                        modifier = Modifier
                            .windowInsetsPadding(WindowInsets.navigationBars)
                            .testTag("bottom_nav_bar")
                    ) {
                        NavigationBarItem(
                            selected = selectedTab == 0,
                            onClick = { selectedTab = 0 },
                            icon = {
                                Icon(
                                    imageVector = Icons.Default.Home,
                                    contentDescription = strings.tabHome,
                                    modifier = Modifier.size(24.dp)
                                )
                            },
                            label = {
                                Text(
                                    strings.tabHome,
                                    fontSize = 11.sp,
                                    fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = DarkBackground,
                                indicatorColor = LimeGreen,
                                selectedTextColor = LimeGreen,
                                unselectedIconColor = TextMutedGray,
                                unselectedTextColor = TextMutedGray
                            ),
                            modifier = Modifier.testTag("nav_tab_home")
                        )

                        NavigationBarItem(
                            selected = selectedTab == 1,
                            onClick = { selectedTab = 1 },
                            icon = {
                                Icon(
                                    imageVector = Icons.Default.Restaurant,
                                    contentDescription = strings.tabNutrition,
                                    modifier = Modifier.size(24.dp)
                                )
                            },
                            label = {
                                Text(
                                    strings.tabNutrition,
                                    fontSize = 11.sp,
                                    fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = DarkBackground,
                                indicatorColor = LimeGreen,
                                selectedTextColor = LimeGreen,
                                unselectedIconColor = TextMutedGray,
                                unselectedTextColor = TextMutedGray
                            ),
                            modifier = Modifier.testTag("nav_tab_nutrition")
                        )

                        NavigationBarItem(
                            selected = selectedTab == 2,
                            onClick = { selectedTab = 2 },
                            icon = {
                                Icon(
                                    imageVector = Icons.Default.FitnessCenter,
                                    contentDescription = strings.tabWorkouts,
                                    modifier = Modifier.size(24.dp)
                                )
                            },
                            label = {
                                Text(
                                    strings.tabWorkouts,
                                    fontSize = 11.sp,
                                    fontWeight = if (selectedTab == 2) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = DarkBackground,
                                indicatorColor = LimeGreen,
                                selectedTextColor = LimeGreen,
                                unselectedIconColor = TextMutedGray,
                                unselectedTextColor = TextMutedGray
                            ),
                            modifier = Modifier.testTag("nav_tab_workouts")
                        )

                        NavigationBarItem(
                            selected = selectedTab == 3,
                            onClick = { selectedTab = 3 },
                            icon = {
                                Icon(
                                    imageVector = Icons.Default.ShowChart,
                                    contentDescription = strings.tabProgress,
                                    modifier = Modifier.size(24.dp)
                                )
                            },
                            label = {
                                Text(
                                    strings.tabProgress,
                                    fontSize = 11.sp,
                                    fontWeight = if (selectedTab == 3) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = DarkBackground,
                                indicatorColor = LimeGreen,
                                selectedTextColor = LimeGreen,
                                unselectedIconColor = TextMutedGray,
                                unselectedTextColor = TextMutedGray
                            ),
                            modifier = Modifier.testTag("nav_tab_progress")
                        )

                        NavigationBarItem(
                            selected = selectedTab == 4,
                            onClick = { selectedTab = 4 },
                            icon = {
                                Icon(
                                    imageVector = Icons.Default.Person,
                                    contentDescription = strings.tabProfile,
                                    modifier = Modifier.size(24.dp)
                                )
                            },
                            label = {
                                Text(
                                    strings.tabProfile,
                                    fontSize = 11.sp,
                                    fontWeight = if (selectedTab == 4) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = DarkBackground,
                                indicatorColor = LimeGreen,
                                selectedTextColor = LimeGreen,
                                unselectedIconColor = TextMutedGray,
                                unselectedTextColor = TextMutedGray
                            ),
                            modifier = Modifier.testTag("nav_tab_profile")
                        )
                    }
                }
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    when (selectedTab) {
                        0 -> HomeScreen(
                            userProfile = profile,
                            todayFoodLogs = todayFoodLogs,
                            todayWaterLog = todayWaterLog,
                            strings = strings,
                            onNavigateToNutrition = { selectedTab = 1 },
                            onNavigateToWorkouts = { selectedTab = 2 },
                            onNavigateToCoach = { selectedTab = 4 },
                            onAddWater = { additionalMl ->
                                coroutineScope.launch {
                                    val current = todayWaterLog?.amountMl ?: 0
                                    repository.setTodayWaterAmount(current + additionalMl)
                                }
                            },
                            onDeleteFoodLog = { foodLog ->
                                coroutineScope.launch {
                                    repository.removeFoodLog(foodLog)
                                }
                            }
                        )

                        1 -> NutritionScreen(
                            userProfile = profile,
                            todayFoodLogs = todayFoodLogs,
                            strings = strings,
                            onAddFoodLog = { log ->
                                coroutineScope.launch {
                                    repository.addFoodLog(log)
                                }
                            },
                            onDeleteFoodLog = { log ->
                                coroutineScope.launch {
                                    repository.removeFoodLog(log)
                                }
                            }
                        )

                        2 -> WorkoutsScreen(
                            recentLogs = workoutLogs,
                            strings = strings,
                            onSaveWorkoutSet = { setLog ->
                                coroutineScope.launch {
                                    repository.logWorkoutSet(setLog)
                                }
                            }
                        )

                        3 -> ProgressScreen(
                            userProfile = profile,
                            measurements = measurements,
                            strings = strings,
                            onSaveMeasurement = { measurement ->
                                coroutineScope.launch {
                                    repository.addMeasurement(measurement)
                                }
                            }
                        )

                        4 -> ProfileAndCoachScreen(
                            userProfile = profile,
                            currentLanguage = activeLanguage,
                            strings = strings,
                            caloriesToday = todayFoodLogs.sumOf { it.calories },
                            proteinToday = todayFoodLogs.map { it.proteinGrams }.sum(),
                            onLanguageChanged = { newLang ->
                                activeLanguage = newLang
                                coroutineScope.launch {
                                    repository.saveUserProfile(
                                        profile.copy(
                                            selectedLanguage = newLang.code,
                                            isRtl = newLang.isRtl
                                        )
                                    )
                                }
                            },
                            onEditProfileRequested = {
                                isEditingProfileInApp = true
                            }
                        )
                    }
                }
            }
        }
    }
}
