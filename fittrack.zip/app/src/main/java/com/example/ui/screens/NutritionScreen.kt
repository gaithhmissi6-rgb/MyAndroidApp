package com.example.ui.screens

import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ai.FoodScannerEngine
import com.example.ai.ParsedFoodPortion
import com.example.ai.ScanResult
import com.example.data.local.FoodLogEntity
import com.example.data.local.UserProfileEntity
import com.example.localization.AppStrings
import com.example.model.FoodCatalog
import com.example.model.FoodItem
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentOrange
import com.example.ui.theme.AccentRed
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.DarkSurfaceHighlight
import com.example.ui.theme.LimeGreen
import com.example.ui.theme.TextMutedGray
import com.example.ui.theme.TextWhite

@Composable
fun NutritionScreen(
    userProfile: UserProfileEntity,
    todayFoodLogs: List<FoodLogEntity>,
    strings: AppStrings,
    onAddFoodLog: (FoodLogEntity) -> Unit,
    onDeleteFoodLog: (FoodLogEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    var showAddDialog by remember { mutableStateOf(false) }
    var selectedMealCategory by remember { mutableStateOf("BREAKFAST") } // BREAKFAST, LUNCH, DINNER, SNACK

    val breakfastLogs = todayFoodLogs.filter { it.mealType == "BREAKFAST" }
    val lunchLogs = todayFoodLogs.filter { it.mealType == "LUNCH" }
    val dinnerLogs = todayFoodLogs.filter { it.mealType == "DINNER" }
    val snackLogs = todayFoodLogs.filter { it.mealType == "SNACK" }

    val totalCals = todayFoodLogs.sumOf { it.calories }
    val totalProtein = todayFoodLogs.map { it.proteinGrams }.sum()
    val totalCarbs = todayFoodLogs.map { it.carbsGrams }.sum()
    val totalFat = todayFoodLogs.map { it.fatGrams }.sum()

    Box(modifier = modifier.fillMaxSize().background(DarkBackground)) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(8.dp))
                // Title & Daily Summary Banner
                Text(
                    text = strings.tabNutrition,
                    style = MaterialTheme.typography.headlineMedium.copy(
                        color = TextWhite,
                        fontWeight = FontWeight.Bold
                    )
                )
                Text(
                    text = "$totalCals / ${userProfile.dailyCalorieTarget} ${strings.kcal} • P: ${totalProtein.toInt()}g | C: ${totalCarbs.toInt()}g | F: ${totalFat.toInt()}g",
                    style = MaterialTheme.typography.bodyMedium.copy(color = LimeGreen)
                )
            }

            // 4 Meal Cards
            item {
                MealSectionCard(
                    title = strings.breakfast,
                    emoji = "🍳",
                    logs = breakfastLogs,
                    strings = strings,
                    onAddClicked = {
                        selectedMealCategory = "BREAKFAST"
                        showAddDialog = true
                    },
                    onDelete = onDeleteFoodLog
                )
            }

            item {
                MealSectionCard(
                    title = strings.lunch,
                    emoji = "🍲",
                    logs = lunchLogs,
                    strings = strings,
                    onAddClicked = {
                        selectedMealCategory = "LUNCH"
                        showAddDialog = true
                    },
                    onDelete = onDeleteFoodLog
                )
            }

            item {
                MealSectionCard(
                    title = strings.dinner,
                    emoji = "🥗",
                    logs = dinnerLogs,
                    strings = strings,
                    onAddClicked = {
                        selectedMealCategory = "DINNER"
                        showAddDialog = true
                    },
                    onDelete = onDeleteFoodLog
                )
            }

            item {
                MealSectionCard(
                    title = strings.snacks,
                    emoji = "🍎",
                    logs = snackLogs,
                    strings = strings,
                    onAddClicked = {
                        selectedMealCategory = "SNACK"
                        showAddDialog = true
                    },
                    onDelete = onDeleteFoodLog
                )
            }

            // Traditional Emirati, Tunisian & Arab Specialties Highlight
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated)
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        // High-res culinary photo of Emirati Machboos
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp)
                        ) {
                            androidx.compose.foundation.Image(
                                painter = androidx.compose.ui.res.painterResource(id = com.example.R.drawable.img_emirati_machboos),
                                contentDescription = "Traditional Emirati Machboos Plate",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = androidx.compose.ui.layout.ContentScale.Crop
                            )
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(
                                        androidx.compose.ui.graphics.Brush.verticalGradient(
                                            colors = listOf(
                                                Color.Transparent,
                                                Color(0xDD13151D)
                                            )
                                        )
                                    )
                            )
                            Row(
                                modifier = Modifier
                                    .align(Alignment.BottomStart)
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("🇦🇪 ", fontSize = 20.sp)
                                Column {
                                    Text(
                                        text = "المطبخ الإماراتي والعربي الأصيل",
                                        color = TextWhite,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp
                                    )
                                    Text(
                                        text = "Emirati Machboos, Harees & Saloona (Healthy Macros)",
                                        color = LimeGreen,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        }

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp)
                        ) {
                            Text(
                                text = "Instant logging for Emirati & Tunisian heritage meals: Machboos, Harees, Saloona, Couscous, Brik, and Lablabi.",
                                style = MaterialTheme.typography.bodySmall.copy(color = TextMutedGray)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(
                                    onClick = {
                                        val machboos = FoodCatalog.items.first { it.id == "emirati_machboos" }
                                        onAddFoodLog(
                                            FoodLogEntity(
                                                dateString = com.example.data.FitTrackRepository.getTodayDateString(),
                                                mealType = "LUNCH",
                                                foodName = machboos.nameEn,
                                                foodNameAr = machboos.nameAr,
                                                foodNameFr = machboos.nameFr,
                                                amountGramsOrMl = 350f,
                                                calories = machboos.calculateCalories(350f),
                                                proteinGrams = machboos.calculateProtein(350f),
                                                carbsGrams = machboos.calculateCarbs(350f),
                                                fatGrams = machboos.calculateFat(350f)
                                            )
                                        )
                                    }
                                ) {
                                    Text("🇦🇪 مجبوس", color = LimeGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                                OutlinedButton(
                                    onClick = {
                                        val harees = FoodCatalog.items.first { it.id == "emirati_harees" }
                                        onAddFoodLog(
                                            FoodLogEntity(
                                                dateString = com.example.data.FitTrackRepository.getTodayDateString(),
                                                mealType = "DINNER",
                                                foodName = harees.nameEn,
                                                foodNameAr = harees.nameAr,
                                                foodNameFr = harees.nameFr,
                                                amountGramsOrMl = 300f,
                                                calories = harees.calculateCalories(300f),
                                                proteinGrams = harees.calculateProtein(300f),
                                                carbsGrams = harees.calculateCarbs(300f),
                                                fatGrams = harees.calculateFat(300f)
                                            )
                                        )
                                    }
                                ) {
                                    Text("🥣 هريس", color = AccentCyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                                OutlinedButton(
                                    onClick = {
                                        val couscous = FoodCatalog.items.first { it.id == "couscous" }
                                        onAddFoodLog(
                                            FoodLogEntity(
                                                dateString = com.example.data.FitTrackRepository.getTodayDateString(),
                                                mealType = "LUNCH",
                                                foodName = couscous.nameEn,
                                                foodNameAr = couscous.nameAr,
                                                foodNameFr = couscous.nameFr,
                                                amountGramsOrMl = 350f,
                                                calories = couscous.calculateCalories(350f),
                                                proteinGrams = couscous.calculateProtein(350f),
                                                carbsGrams = couscous.calculateCarbs(350f),
                                                fatGrams = couscous.calculateFat(350f)
                                            )
                                        )
                                    }
                                ) {
                                    Text("🍲 كسكسي", color = AccentOrange, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(80.dp))
            }
        }

        // Floating Action Button to Add Food
        FloatingActionButton(
            onClick = { showAddDialog = true },
            containerColor = LimeGreen,
            contentColor = DarkBackground,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp)
                .testTag("fab_add_food")
        ) {
            Icon(imageVector = Icons.Default.Add, contentDescription = "Add Food")
        }

        // Add Meal Dialog
        if (showAddDialog) {
            SmartFoodAddDialog(
                defaultMealType = selectedMealCategory,
                strings = strings,
                onDismiss = { showAddDialog = false },
                onAddFoods = { items, mealType ->
                    items.forEach { item ->
                        onAddFoodLog(
                            FoodLogEntity(
                                dateString = com.example.data.FitTrackRepository.getTodayDateString(),
                                mealType = mealType,
                                foodName = item.foodItem.nameEn,
                                foodNameAr = item.foodItem.nameAr,
                                foodNameFr = item.foodItem.nameFr,
                                amountGramsOrMl = item.quantityGramsOrMl,
                                calories = item.calories,
                                proteinGrams = item.protein,
                                carbsGrams = item.carbs,
                                fatGrams = item.fat
                            )
                        )
                    }
                    showAddDialog = false
                }
            )
        }
    }
}

@Composable
private fun MealSectionCard(
    title: String,
    emoji: String,
    logs: List<FoodLogEntity>,
    strings: AppStrings,
    onAddClicked: () -> Unit,
    onDelete: (FoodLogEntity) -> Unit
) {
    val totalCals = logs.sumOf { it.calories }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(text = emoji, fontSize = 22.sp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = TextWhite,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "$totalCals ${strings.kcal}",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = LimeGreen,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    IconButton(onClick = onAddClicked) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Add",
                            tint = LimeGreen
                        )
                    }
                }
            }

            if (logs.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                logs.forEach { log ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = log.foodName,
                                style = MaterialTheme.typography.bodyMedium.copy(color = TextWhite)
                            )
                            Text(
                                text = "${log.amountGramsOrMl.toInt()}g • P:${log.proteinGrams.toInt()}g C:${log.carbsGrams.toInt()}g F:${log.fatGrams.toInt()}g",
                                style = MaterialTheme.typography.bodySmall.copy(color = TextMutedGray)
                            )
                        }
                        Text(
                            text = "${log.calories} kcal",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = TextWhite,
                                fontWeight = FontWeight.SemiBold
                            )
                        )
                        IconButton(onClick = { onDelete(log) }) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Delete",
                                tint = AccentRed.copy(alpha = 0.6f),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SmartFoodAddDialog(
    defaultMealType: String,
    strings: AppStrings,
    onDismiss: () -> Unit,
    onAddFoods: (List<ParsedFoodPortion>, String) -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) } // 0: Photo, 1: Text NLP, 2: Voice, 3: Catalog
    var mealType by remember { mutableStateOf(defaultMealType) }

    // State for Text NLP
    var textInputState by remember { mutableStateOf("") }
    // State for Voice NLP
    var voiceTranscript by remember { mutableStateOf("") }
    var isRecording by remember { mutableStateOf(false) }
    // State for Search
    var searchQuery by remember { mutableStateOf("") }

    // Active parsed items ready to log
    var currentReviewItems by remember { mutableStateOf<MutableList<ParsedFoodPortion>>(mutableListOf()) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp)
                .testTag("smart_food_add_dialog"),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                // Header with close
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = strings.addFoodTitle,
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = LimeGreen,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = TextMutedGray)
                    }
                }

                // Meal Category Selector
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf("BREAKFAST", "LUNCH", "DINNER", "SNACK").forEach { cat ->
                        val isSelected = cat == mealType
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSelected) LimeGreen else DarkSurfaceElevated)
                                .clickable { mealType = cat }
                                .padding(vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = when (cat) {
                                    "BREAKFAST" -> strings.breakfast
                                    "LUNCH" -> strings.lunch
                                    "DINNER" -> strings.dinner
                                    else -> strings.snacks
                                },
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = if (isSelected) DarkBackground else TextWhite,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // 4 Tab Bar
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = DarkSurfaceElevated,
                    contentColor = LimeGreen,
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                            color = LimeGreen
                        )
                    }
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = { Text("Photo", fontSize = 11.sp) },
                        icon = { Icon(Icons.Default.CameraAlt, contentDescription = null, modifier = Modifier.size(16.dp)) }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = { Text("Text", fontSize = 11.sp) },
                        icon = { Icon(Icons.Default.Keyboard, contentDescription = null, modifier = Modifier.size(16.dp)) }
                    )
                    Tab(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        text = { Text("Voice", fontSize = 11.sp) },
                        icon = { Icon(Icons.Default.Mic, contentDescription = null, modifier = Modifier.size(16.dp)) }
                    )
                    Tab(
                        selected = selectedTab == 3,
                        onClick = { selectedTab = 3 },
                        text = { Text("Search", fontSize = 11.sp) },
                        icon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(16.dp)) }
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Content for each tab
                when (selectedTab) {
                    0 -> {
                        // Photo recognition tab with presets & disclaimer
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Text(
                                text = strings.estimateDisclaimer,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = AccentOrange,
                                    fontSize = 11.sp
                                )
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Select meal to scan & analyze portions:",
                                style = MaterialTheme.typography.bodySmall.copy(color = TextWhite)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            LazyColumn(modifier = Modifier.height(180.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                items(FoodScannerEngine.presetVisualMeals) { preset ->
                                    Card(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                currentReviewItems = preset.items.toMutableList()
                                            },
                                        colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated)
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(10.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(preset.title, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                                Text(preset.notes, color = TextMutedGray, fontSize = 11.sp)
                                            }
                                            Text("${preset.totalCalories} kcal", color = LimeGreen, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    1 -> {
                        // Text Natural Language Input
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Text(
                                text = strings.sampleTextPrompt,
                                style = MaterialTheme.typography.bodySmall.copy(color = TextMutedGray)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedTextField(
                                value = textInputState,
                                onValueChange = { textInputState = it },
                                placeholder = { Text("3 eggs, 250 ml milk, 150 g chicken", color = TextMutedGray) },
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = TextWhite,
                                    unfocusedTextColor = TextWhite,
                                    focusedBorderColor = LimeGreen,
                                    unfocusedBorderColor = DarkSurfaceElevated
                                )
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(
                                onClick = {
                                    if (textInputState.isNotBlank()) {
                                        val result = FoodScannerEngine.parseNaturalLanguage(textInputState)
                                        currentReviewItems = result.items.toMutableList()
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = LimeGreen, contentColor = DarkBackground)
                            ) {
                                Text(strings.parseAndCalculate, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    2 -> {
                        // Voice Recognition Input
                        val context = LocalContext.current
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = strings.sampleVoicePrompt,
                                style = MaterialTheme.typography.bodySmall.copy(color = TextMutedGray)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Box(
                                modifier = Modifier
                                    .size(70.dp)
                                    .clip(CircleShape)
                                    .background(if (isRecording) AccentRed else LimeGreen)
                                    .clickable {
                                        isRecording = !isRecording
                                        if (isRecording) {
                                            // Simulate or start speech listener
                                            voiceTranscript = "3 eggs, 250 ml milk and 150 g chicken"
                                            val result = FoodScannerEngine.parseNaturalLanguage(voiceTranscript)
                                            currentReviewItems = result.items.toMutableList()
                                        }
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Mic,
                                    contentDescription = "Microphone",
                                    tint = DarkBackground,
                                    modifier = Modifier.size(32.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = if (isRecording) strings.listening else strings.tapToSpeak,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = if (isRecording) AccentRed else TextWhite,
                                    fontWeight = FontWeight.SemiBold
                                )
                            )
                            if (voiceTranscript.isNotEmpty()) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "\"$voiceTranscript\"",
                                    style = MaterialTheme.typography.bodySmall.copy(color = AccentCyan)
                                )
                            }
                        }
                    }

                    3 -> {
                        // Search Catalog
                        Column(modifier = Modifier.fillMaxWidth()) {
                            OutlinedTextField(
                                value = searchQuery,
                                onValueChange = { searchQuery = it },
                                placeholder = { Text(strings.searchPlaceholder, color = TextMutedGray, fontSize = 12.sp) },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = TextWhite,
                                    unfocusedTextColor = TextWhite,
                                    focusedBorderColor = LimeGreen,
                                    unfocusedBorderColor = DarkSurfaceElevated
                                )
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            val searchResults = FoodCatalog.search(searchQuery)
                            LazyColumn(modifier = Modifier.height(180.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                items(searchResults) { food ->
                                    Card(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                currentReviewItems = mutableListOf(
                                                    ParsedFoodPortion(food, food.defaultServingGrams, food.nameEn)
                                                )
                                            },
                                        colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated)
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(10.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(food.iconEmoji, fontSize = 20.sp)
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Column {
                                                    Text(food.nameEn, color = TextWhite, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                                    Text("${food.nameAr} • ${food.defaultServingGrams.toInt()}g", color = TextMutedGray, fontSize = 11.sp)
                                                }
                                            }
                                            Text("${food.calculateCalories(food.defaultServingGrams)} kcal", color = LimeGreen, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Editable Breakdown Section
                if (currentReviewItems.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Review & Edit Quantities:",
                        style = MaterialTheme.typography.titleSmall.copy(color = TextWhite, fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyColumn(modifier = Modifier.height(110.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        items(currentReviewItems) { item ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(DarkSurfaceElevated, RoundedCornerShape(8.dp))
                                    .padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(item.foodItem.nameEn, color = TextWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    Text("${item.calories} kcal | P:${item.protein.toInt()}g C:${item.carbs.toInt()}g F:${item.fat.toInt()}g", color = TextMutedGray, fontSize = 10.sp)
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    OutlinedButton(
                                        onClick = {
                                            item.quantityGramsOrMl = (item.quantityGramsOrMl - 25f).coerceAtLeast(25f)
                                            currentReviewItems = currentReviewItems.toMutableList()
                                        },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Text("-", color = TextWhite, fontSize = 10.sp)
                                    }
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("${item.quantityGramsOrMl.toInt()}g", color = LimeGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    OutlinedButton(
                                        onClick = {
                                            item.quantityGramsOrMl += 25f
                                            currentReviewItems = currentReviewItems.toMutableList()
                                        },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Text("+", color = TextWhite, fontSize = 10.sp)
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            onAddFoods(currentReviewItems, mealType)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("confirm_log_meal_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = LimeGreen, contentColor = DarkBackground)
                    ) {
                        Text("${strings.addMealButton} (${currentReviewItems.sumOf { it.calories }} kcal)", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
