package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.AppStrings
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentOrange
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.LimeGreen
import com.example.ui.theme.TextMutedGray
import com.example.ui.theme.TextWhite

@Composable
fun CircularMacroRing(
    caloriesConsumed: Int,
    calorieGoal: Int,
    proteinGrams: Float,
    proteinGoal: Int,
    carbsGrams: Float,
    carbsGoal: Int,
    fatGrams: Float,
    fatGoal: Int,
    strings: AppStrings,
    modifier: Modifier = Modifier
) {
    val remainingCalories = (calorieGoal - caloriesConsumed).coerceAtLeast(0)
    val progress = if (calorieGoal > 0) (caloriesConsumed.toFloat() / calorieGoal.toFloat()).coerceIn(0f, 1.2f) else 0f

    val animatedProgress = remember { Animatable(0f) }
    LaunchedEffect(progress) {
        animatedProgress.animateTo(progress, animationSpec = tween(durationMillis = 800))
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("dashboard_calorie_card"),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Main Calorie Gauge
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.size(190.dp)
            ) {
                Canvas(modifier = Modifier.size(180.dp)) {
                    val strokeWidth = 14.dp.toPx()
                    // Background track
                    drawCircle(
                        color = Color(0xFF1E222F),
                        style = Stroke(width = strokeWidth)
                    )
                    // Animated arc
                    val sweepAngle = (animatedProgress.value.coerceAtMost(1f)) * 360f
                    drawArc(
                        color = LimeGreen,
                        startAngle = -90f,
                        sweepAngle = sweepAngle,
                        useCenter = false,
                        style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                    )
                }

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "$remainingCalories",
                        style = MaterialTheme.typography.displaySmall.copy(
                            fontWeight = FontWeight.Black,
                            color = TextWhite,
                            fontSize = 36.sp
                        )
                    )
                    Text(
                        text = strings.caloriesRemaining,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = TextMutedGray,
                            fontWeight = FontWeight.Medium
                        )
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "$caloriesConsumed / $calorieGoal ${strings.kcal}",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = LimeGreen,
                            fontWeight = FontWeight.SemiBold
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // 3 Macronutrient Progress Bars
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                MacroPill(
                    name = strings.protein,
                    current = proteinGrams.toInt(),
                    goal = proteinGoal,
                    unit = strings.gramsUnit,
                    barColor = AccentCyan,
                    modifier = Modifier.weight(1f)
                )
                MacroPill(
                    name = strings.carbs,
                    current = carbsGrams.toInt(),
                    goal = carbsGoal,
                    unit = strings.gramsUnit,
                    barColor = LimeGreen,
                    modifier = Modifier.weight(1f)
                )
                MacroPill(
                    name = strings.fat,
                    current = fatGrams.toInt(),
                    goal = fatGoal,
                    unit = strings.gramsUnit,
                    barColor = AccentOrange,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun MacroPill(
    name: String,
    current: Int,
    goal: Int,
    unit: String,
    barColor: Color,
    modifier: Modifier = Modifier
) {
    val ratio = if (goal > 0) (current.toFloat() / goal.toFloat()).coerceIn(0f, 1f) else 0f

    Column(
        modifier = modifier.padding(horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(barColor)
            )
            Text(
                text = " $name",
                style = MaterialTheme.typography.labelSmall.copy(
                    color = TextMutedGray,
                    fontWeight = FontWeight.Medium
                ),
                maxLines = 1
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "$current/$goal$unit",
            style = MaterialTheme.typography.bodySmall.copy(
                color = TextWhite,
                fontWeight = FontWeight.Bold
            )
        )
        Spacer(modifier = Modifier.height(6.dp))
        // Progress bar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp))
                .background(Color(0xFF232736))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(ratio)
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(barColor)
            )
        }
    }
}
