package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.local.BodyMeasurementEntity
import com.example.data.local.UserProfileEntity
import com.example.localization.AppStrings
import com.example.ui.components.ChartPoint
import com.example.ui.components.LineProgressChart
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentOrange
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.DarkSurfaceHighlight
import com.example.ui.theme.LimeGreen
import com.example.ui.theme.TextMutedGray
import com.example.ui.theme.TextWhite

@Composable
fun ProgressScreen(
    userProfile: UserProfileEntity,
    measurements: List<BodyMeasurementEntity>,
    strings: AppStrings,
    onSaveMeasurement: (BodyMeasurementEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    var showAddDialog by remember { mutableStateOf(false) }

    val latestWeight = measurements.lastOrNull()?.weightKg ?: userProfile.currentWeightKg
    val heightM = userProfile.heightCm / 100f
    val bmi = if (heightM > 0f) latestWeight / (heightM * heightM) else 22f

    val bmiCategory = when {
        bmi < 18.5f -> "Underweight"
        bmi in 18.5f..24.9f -> "Normal & Healthy"
        bmi in 25.0f..29.9f -> "Overweight"
        else -> "Obese"
    }

    val bmiColor = when {
        bmi in 18.5f..24.9f -> LimeGreen
        bmi < 18.5f -> AccentCyan
        bmi in 25.0f..29.9f -> AccentOrange
        else -> Color(0xFFFF5252)
    }

    val chartPoints = measurements.takeLast(7).map { m ->
        ChartPoint(label = m.dateString.takeLast(5), value = m.weightKg)
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = strings.tabProgress,
                        style = MaterialTheme.typography.headlineMedium.copy(
                            color = TextWhite,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Text(
                        text = "Goal: ${userProfile.targetWeightKg} kg • Current: $latestWeight kg",
                        style = MaterialTheme.typography.bodyMedium.copy(color = LimeGreen)
                    )
                }

                Button(
                    onClick = { showAddDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = LimeGreen, contentColor = DarkBackground),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("log_measurement_btn")
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Log", fontWeight = FontWeight.Bold)
                }
            }
        }

        // BMI Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = strings.bmiTitle,
                            style = MaterialTheme.typography.titleSmall.copy(color = TextMutedGray)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = String.format("%.1f", bmi),
                            style = MaterialTheme.typography.displaySmall.copy(
                                color = TextWhite,
                                fontWeight = FontWeight.Black
                            )
                        )
                        Text(
                            text = bmiCategory,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = bmiColor,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }

                    // BMI Scale representation
                    Column(
                        horizontalAlignment = Alignment.End
                    ) {
                        Text(
                            text = "Height: ${userProfile.heightCm.toInt()} cm",
                            color = TextMutedGray,
                            fontSize = 12.sp
                        )
                        Text(
                            text = "Weight: $latestWeight kg",
                            color = TextMutedGray,
                            fontSize = 12.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(bmiColor.copy(alpha = 0.15f))
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "Healthy Range: 18.5 - 24.9",
                                color = bmiColor,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }

        // Weight Progress Trend Chart
        item {
            LineProgressChart(
                title = strings.weightProgress,
                points = chartPoints,
                unit = "kg",
                accentColor = LimeGreen
            )
        }

        // Body Circumference Measurements (Chest, Arm, Waist, Thigh, Calf)
        item {
            val latest = measurements.lastOrNull()
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Text(
                        text = strings.bodyTrackerTitle,
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = TextWhite,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        MeasurementItem(name = strings.waistMeasure, value = latest?.waistCm ?: 82f)
                        MeasurementItem(name = strings.chestMeasure, value = latest?.chestCm ?: 102f)
                        MeasurementItem(name = strings.armMeasure, value = latest?.armCm ?: 37f)
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        MeasurementItem(name = strings.thighMeasure, value = latest?.thighCm ?: 58f)
                        MeasurementItem(name = strings.calfMeasure, value = latest?.calfCm ?: 38f)
                    }
                }
            }
        }

        // Progress Photo Journal Logs
        item {
            Text(
                text = strings.photoJournal,
                style = MaterialTheme.typography.titleMedium.copy(
                    color = TextWhite,
                    fontWeight = FontWeight.Bold
                )
            )
        }

        items(measurements.reversed()) { record ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(LimeGreen.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.PhotoCamera,
                                contentDescription = null,
                                tint = LimeGreen,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "${record.weightKg} kg on ${record.dateString}",
                                color = TextWhite,
                                fontWeight = FontWeight.Bold
                            )
                            if (!record.photoNote.isNullOrEmpty()) {
                                Text(
                                    text = record.photoNote,
                                    color = TextMutedGray,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }

                    if (record.waistCm != null) {
                        Text(
                            text = "Waist: ${record.waistCm.toInt()} cm",
                            color = AccentCyan,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(40.dp))
        }
    }

    // Measurement Input Dialog
    if (showAddDialog) {
        MeasurementInputDialog(
            defaultWeight = latestWeight,
            strings = strings,
            onDismiss = { showAddDialog = false },
            onSave = { entry ->
                onSaveMeasurement(entry)
                showAddDialog = false
            }
        )
    }
}

@Composable
private fun MeasurementItem(name: String, value: Float) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = "${value.toInt()} cm",
            style = MaterialTheme.typography.titleMedium.copy(
                color = LimeGreen,
                fontWeight = FontWeight.Bold
            )
        )
        Text(
            text = name,
            style = MaterialTheme.typography.labelSmall.copy(color = TextMutedGray)
        )
    }
}

@Composable
private fun MeasurementInputDialog(
    defaultWeight: Float,
    strings: AppStrings,
    onDismiss: () -> Unit,
    onSave: (BodyMeasurementEntity) -> Unit
) {
    var weightStr by remember { mutableStateOf(defaultWeight.toString()) }
    var waistStr by remember { mutableStateOf("80") }
    var chestStr by remember { mutableStateOf("100") }
    var armStr by remember { mutableStateOf("36") }
    var thighStr by remember { mutableStateOf("56") }
    var noteStr by remember { mutableStateOf("Feeling stronger and leaner") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp)
                .testTag("body_measurement_dialog"),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = strings.logMeasurement,
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = LimeGreen,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = TextMutedGray)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = weightStr,
                    onValueChange = { weightStr = it },
                    label = { Text("Weight (kg)", color = TextMutedGray) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextWhite,
                        unfocusedTextColor = TextWhite,
                        focusedBorderColor = LimeGreen,
                        unfocusedBorderColor = DarkSurfaceHighlight
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = waistStr,
                        onValueChange = { waistStr = it },
                        label = { Text("Waist (cm)", color = TextMutedGray, fontSize = 11.sp) },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextWhite,
                            unfocusedTextColor = TextWhite,
                            focusedBorderColor = LimeGreen,
                            unfocusedBorderColor = DarkSurfaceHighlight
                        )
                    )
                    OutlinedTextField(
                        value = armStr,
                        onValueChange = { armStr = it },
                        label = { Text("Arm (cm)", color = TextMutedGray, fontSize = 11.sp) },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextWhite,
                            unfocusedTextColor = TextWhite,
                            focusedBorderColor = LimeGreen,
                            unfocusedBorderColor = DarkSurfaceHighlight
                        )
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = chestStr,
                        onValueChange = { chestStr = it },
                        label = { Text("Chest (cm)", color = TextMutedGray, fontSize = 11.sp) },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextWhite,
                            unfocusedTextColor = TextWhite,
                            focusedBorderColor = LimeGreen,
                            unfocusedBorderColor = DarkSurfaceHighlight
                        )
                    )
                    OutlinedTextField(
                        value = thighStr,
                        onValueChange = { thighStr = it },
                        label = { Text("Thigh (cm)", color = TextMutedGray, fontSize = 11.sp) },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextWhite,
                            unfocusedTextColor = TextWhite,
                            focusedBorderColor = LimeGreen,
                            unfocusedBorderColor = DarkSurfaceHighlight
                        )
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = noteStr,
                    onValueChange = { noteStr = it },
                    label = { Text("Journal Note", color = TextMutedGray) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextWhite,
                        unfocusedTextColor = TextWhite,
                        focusedBorderColor = LimeGreen,
                        unfocusedBorderColor = DarkSurfaceHighlight
                    )
                )

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        val w = weightStr.toFloatOrNull() ?: defaultWeight
                        val waist = waistStr.toFloatOrNull()
                        val arm = armStr.toFloatOrNull()
                        val chest = chestStr.toFloatOrNull()
                        val thigh = thighStr.toFloatOrNull()
                        onSave(
                            BodyMeasurementEntity(
                                dateString = com.example.data.FitTrackRepository.getTodayDateString(),
                                weightKg = w,
                                waistCm = waist,
                                armCm = arm,
                                chestCm = chest,
                                thighCm = thigh,
                                photoNote = noteStr
                            )
                        )
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = LimeGreen, contentColor = DarkBackground)
                ) {
                    Text("Save Measurement", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
