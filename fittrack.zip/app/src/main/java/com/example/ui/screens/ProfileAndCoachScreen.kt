package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ai.CoachMessage
import com.example.ai.FitnessCoachEngine
import com.example.data.local.UserProfileEntity
import com.example.localization.AppStrings
import com.example.localization.Language
import com.example.ui.components.LanguagePickerDialog
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentOrange
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.DarkSurfaceHighlight
import com.example.ui.theme.LimeGreen
import com.example.ui.theme.TextLightGray
import com.example.ui.theme.TextMutedGray
import com.example.ui.theme.TextWhite

@Composable
fun ProfileAndCoachScreen(
    userProfile: UserProfileEntity,
    currentLanguage: Language,
    strings: AppStrings,
    caloriesToday: Int = 0,
    proteinToday: Float = 0f,
    onLanguageChanged: (Language) -> Unit,
    onEditProfileRequested: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableIntStateOf(0) } // 0: AI Fitness Coach, 1: Profile & Targets, 2: Achievements
    var showLanguagePicker by remember { mutableStateOf(false) }

    // Coach Chat State
    var promptInput by remember { mutableStateOf("") }
    val chatMessages = remember {
        mutableStateListOf(
            CoachMessage(
                sender = "coach",
                text = FitnessCoachEngine.generateResponse(
                    prompt = "hello",
                    userProfile = userProfile,
                    language = currentLanguage,
                    caloriesConsumedToday = caloriesToday,
                    proteinConsumedToday = proteinToday
                )
            )
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(8.dp))

        // Header with Language Switcher & Profile
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = strings.tabProfile,
                style = MaterialTheme.typography.headlineMedium.copy(
                    color = TextWhite,
                    fontWeight = FontWeight.Bold
                )
            )

            // Language Switcher Button
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(DarkSurfaceElevated)
                    .clickable { showLanguagePicker = true }
                    .padding(horizontal = 10.dp, vertical = 6.dp)
                    .testTag("language_switcher_btn"),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Language,
                    contentDescription = "Language",
                    tint = LimeGreen,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "${currentLanguage.flagEmoji} ${currentLanguage.nativeName}",
                    style = MaterialTheme.typography.labelMedium.copy(
                        color = TextWhite,
                        fontWeight = FontWeight.SemiBold
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Tab Selector
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = DarkSurfaceElevated,
            contentColor = LimeGreen,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                    color = LimeGreen
                )
            }
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("AI Coach", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                icon = { Icon(Icons.Default.Psychology, contentDescription = null, modifier = Modifier.size(16.dp)) }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("Profile & Targets", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                icon = { Icon(Icons.Default.Person, contentDescription = null, modifier = Modifier.size(16.dp)) }
            )
            Tab(
                selected = selectedTab == 2,
                onClick = { selectedTab = 2 },
                text = { Text(strings.achievements, fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                icon = { Icon(Icons.Default.EmojiEvents, contentDescription = null, modifier = Modifier.size(16.dp)) }
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        when (selectedTab) {
            0 -> {
                // AI Fitness Coach Interactive Chat
                Column(modifier = Modifier.fillMaxSize()) {
                    // Quick Suggested Prompts Scrollable Row
                    Text(
                        text = "Suggested Questions:",
                        style = MaterialTheme.typography.labelSmall.copy(color = TextMutedGray)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyColumn(
                        modifier = Modifier.height(95.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        item {
                            QuickPromptChip(strings.promptCalorieNeed) {
                                sendCoachQuery(strings.promptCalorieNeed, userProfile, currentLanguage, caloriesToday, proteinToday, chatMessages)
                            }
                        }
                        item {
                            QuickPromptChip(strings.promptProteinNeed) {
                                sendCoachQuery(strings.promptProteinNeed, userProfile, currentLanguage, caloriesToday, proteinToday, chatMessages)
                            }
                        }
                        item {
                            QuickPromptChip(strings.promptGainMuscle) {
                                sendCoachQuery(strings.promptGainMuscle, userProfile, currentLanguage, caloriesToday, proteinToday, chatMessages)
                            }
                        }
                        item {
                            QuickPromptChip(strings.promptMealSuggest) {
                                sendCoachQuery(strings.promptMealSuggest, userProfile, currentLanguage, caloriesToday, proteinToday, chatMessages)
                            }
                        }
                        item {
                            QuickPromptChip(strings.promptAnalyzeNutrition) {
                                sendCoachQuery(strings.promptAnalyzeNutrition, userProfile, currentLanguage, caloriesToday, proteinToday, chatMessages)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Chat messages list
                    LazyColumn(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(chatMessages) { msg ->
                            val isUser = msg.sender == "user"
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth(0.85f)
                                        .clip(
                                            RoundedCornerShape(
                                                topStart = 16.dp,
                                                topEnd = 16.dp,
                                                bottomStart = if (isUser) 16.dp else 4.dp,
                                                bottomEnd = if (isUser) 4.dp else 16.dp
                                            )
                                        )
                                        .background(if (isUser) LimeGreen else DarkSurfaceElevated)
                                        .padding(14.dp)
                                ) {
                                    Text(
                                        text = msg.text,
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            color = if (isUser) DarkBackground else TextWhite,
                                            lineHeight = 20.sp
                                        )
                                    )
                                }
                            }
                        }
                    }

                    // Input Box
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = promptInput,
                            onValueChange = { promptInput = it },
                            placeholder = { Text(strings.askAnything, color = TextMutedGray, fontSize = 12.sp) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("coach_input_field"),
                            maxLines = 2,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = TextWhite,
                                unfocusedTextColor = TextWhite,
                                focusedBorderColor = LimeGreen,
                                unfocusedBorderColor = DarkSurfaceHighlight
                            )
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        IconButton(
                            onClick = {
                                if (promptInput.isNotBlank()) {
                                    val text = promptInput
                                    promptInput = ""
                                    sendCoachQuery(text, userProfile, currentLanguage, caloriesToday, proteinToday, chatMessages)
                                }
                            },
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(LimeGreen)
                                .testTag("coach_send_btn")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Send,
                                contentDescription = "Send",
                                tint = DarkBackground
                            )
                        }
                    }
                }
            }

            1 -> {
                // Profile & Personalized Targets
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(userProfile.name, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                        Text("${userProfile.age} yrs • ${userProfile.gender} • ${userProfile.experienceLevel}", color = TextMutedGray, fontSize = 12.sp)
                                    }
                                    Button(
                                        onClick = onEditProfileRequested,
                                        colors = ButtonDefaults.buttonColors(containerColor = LimeGreen, contentColor = DarkBackground),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text("Edit Profile", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }

                                Spacer(modifier = Modifier.height(14.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    ProfileStatBadge("Weight", "${userProfile.currentWeightKg} kg")
                                    ProfileStatBadge("Height", "${userProfile.heightCm.toInt()} cm")
                                    ProfileStatBadge("Goal", userProfile.fitnessGoal)
                                }
                            }
                        }
                    }

                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = "Calculated Daily Targets",
                                    color = TextWhite,
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.titleMedium
                                )
                                Spacer(modifier = Modifier.height(12.dp))

                                TargetRow(label = strings.dailyGoal, value = "${userProfile.dailyCalorieTarget} kcal", color = LimeGreen)
                                TargetRow(label = strings.protein, value = "${userProfile.dailyProteinTargetG} g", color = AccentCyan)
                                TargetRow(label = strings.carbs, value = "${userProfile.dailyCarbsTargetG} g", color = LimeGreen)
                                TargetRow(label = strings.fat, value = "${userProfile.dailyFatTargetG} g", color = AccentOrange)
                                TargetRow(label = strings.waterIntake, value = "${userProfile.dailyWaterTargetMl} ml", color = AccentCyan)
                            }
                        }
                    }

                    // Teenager Safety Guidance
                    if (userProfile.age < 18) {
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF261D00))
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Text("Teenager Nutritional Guidance", color = AccentOrange, fontWeight = FontWeight.Bold)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(strings.teenSafetyNotice, color = TextLightGray, fontSize = 12.sp)
                                }
                            }
                        }
                    }

                    item { Spacer(modifier = Modifier.height(40.dp)) }
                }
            }

            2 -> {
                // Personal Achievements & Badges
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    val achievements = listOf(
                        Triple("Hydration Champion 💧", "Logged 2.5L+ water intake for 3 consecutive days", true),
                        Triple("Iron Will 🏋️‍♂️", "Completed a full Push Pull Legs workout cycle", true),
                        Triple("Nutrition Master 🥗", "Hit exact protein targets with clean meals", true),
                        Triple("7-Day Streak 🔥", "Maintained an active tracking streak for 7 days", true),
                        Triple("Smart Scanner 📸", "Scanned and parsed traditional & international meals", true),
                        Triple("Body Transformation 📈", "Logged first 3 body circumference measurement milestones", false)
                    )

                    items(achievements) { (title, desc, isUnlocked) ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isUnlocked) DarkSurfaceElevated else Color(0xFF11131A)
                            )
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(CircleShape)
                                        .background(if (isUnlocked) LimeGreen.copy(alpha = 0.2f) else DarkSurfaceHighlight),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.EmojiEvents,
                                        contentDescription = null,
                                        tint = if (isUnlocked) LimeGreen else TextMutedGray,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = title,
                                        color = if (isUnlocked) TextWhite else TextMutedGray,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = desc,
                                        color = TextMutedGray,
                                        fontSize = 12.sp
                                    )
                                }
                            }
                        }
                    }
                    item { Spacer(modifier = Modifier.height(40.dp)) }
                }
            }
        }
    }

    if (showLanguagePicker) {
        LanguagePickerDialog(
            currentLanguage = currentLanguage,
            onLanguageSelected = { lang ->
                onLanguageChanged(lang)
            },
            onDismiss = { showLanguagePicker = false }
        )
    }
}

private fun sendCoachQuery(
    query: String,
    user: UserProfileEntity,
    lang: Language,
    calsToday: Int,
    proteinToday: Float,
    chatMessages: MutableList<CoachMessage>
) {
    chatMessages.add(CoachMessage(sender = "user", text = query))
    val answer = FitnessCoachEngine.generateResponse(
        prompt = query,
        userProfile = user,
        language = lang,
        caloriesConsumedToday = calsToday,
        proteinConsumedToday = proteinToday
    )
    chatMessages.add(CoachMessage(sender = "coach", text = answer))
}

@Composable
private fun QuickPromptChip(text: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(DarkSurfaceElevated)
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Text(
            text = "💬 $text",
            color = LimeGreen,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 1
        )
    }
}

@Composable
private fun ProfileStatBadge(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = LimeGreen, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Text(label, color = TextMutedGray, fontSize = 11.sp)
    }
}

@Composable
private fun TargetRow(label: String, value: String, color: Color) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = TextMutedGray, fontSize = 13.sp)
        Text(value, color = color, fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }
}
