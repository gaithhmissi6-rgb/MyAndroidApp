package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.local.WorkoutLogEntity
import com.example.localization.AppStrings
import com.example.model.Exercise
import com.example.model.WorkoutDay
import com.example.model.WorkoutLibrary
import com.example.model.WorkoutProgram
import com.example.ui.components.RestTimerDialog
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentOrange
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.DarkSurfaceHighlight
import com.example.ui.theme.LimeGreen
import com.example.ui.theme.TextMutedGray
import com.example.ui.theme.TextWhite

@Composable
fun WorkoutsScreen(
    recentLogs: List<WorkoutLogEntity>,
    strings: AppStrings,
    onSaveWorkoutSet: (WorkoutLogEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableIntStateOf(0) } // 0: Programs, 1: Exercises Library, 2: History
    var activeWorkoutDay by remember { mutableStateOf<WorkoutDay?>(null) }
    var showRestTimer by remember { mutableStateOf(false) }

    Box(modifier = modifier.fillMaxSize().background(DarkBackground)) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = strings.workoutLibrary,
                    style = MaterialTheme.typography.headlineMedium.copy(
                        color = TextWhite,
                        fontWeight = FontWeight.Bold
                    )
                )

                // Quick Rest Timer trigger
                IconButton(onClick = { showRestTimer = true }) {
                    Icon(
                        imageVector = Icons.Default.Timer,
                        contentDescription = "Timer",
                        tint = LimeGreen,
                        modifier = Modifier.size(26.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // 3-way Tab: Programs, Exercise Library, History
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = DarkSurfaceElevated,
                contentColor = LimeGreen,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                        color = LimeGreen
                    )
                }
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text(strings.programs, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text(strings.exercises, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text(strings.workoutHistory, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            when (selectedTab) {
                0 -> {
                    // Workout Programs List (PPL, Upper Lower, Full Body, Bro Split)
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        items(WorkoutLibrary.programs) { program ->
                            ProgramCard(
                                program = program,
                                strings = strings,
                                onStartDay = { day ->
                                    activeWorkoutDay = day
                                }
                            )
                        }
                        item { Spacer(modifier = Modifier.height(40.dp)) }
                    }
                }

                1 -> {
                    // 11 Muscle Groups Exercises
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(WorkoutLibrary.exercises) { exercise ->
                            ExerciseDetailCard(exercise = exercise, strings = strings)
                        }
                        item { Spacer(modifier = Modifier.height(40.dp)) }
                    }
                }

                2 -> {
                    // Workout History Logs
                    if (recentLogs.isEmpty()) {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "No workouts recorded yet. Start a session to log your sets!",
                                color = TextMutedGray,
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            items(recentLogs) { log ->
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(14.dp),
                                    colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(14.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column {
                                            Text(log.exerciseName, color = TextWhite, fontWeight = FontWeight.Bold)
                                            Text(
                                                "${log.programName} • ${log.dateString}",
                                                color = TextMutedGray,
                                                fontSize = 11.sp
                                            )
                                        }
                                        Text(
                                            "Set ${log.setNumber}: ${log.weightKg} kg × ${log.repetitions} reps",
                                            color = LimeGreen,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp
                                        )
                                    }
                                }
                            }
                            item { Spacer(modifier = Modifier.height(40.dp)) }
                        }
                    }
                }
            }
        }

        // Active Workout Live Session Tracker Dialog
        if (activeWorkoutDay != null) {
            ActiveWorkoutSessionDialog(
                day = activeWorkoutDay!!,
                strings = strings,
                onDismiss = { activeWorkoutDay = null },
                onLogSet = { log ->
                    onSaveWorkoutSet(log)
                },
                onOpenRestTimer = { showRestTimer = true }
            )
        }

        // Rest Timer Dialog
        if (showRestTimer) {
            RestTimerDialog(
                initialSeconds = 90,
                strings = strings,
                onDismiss = { showRestTimer = false }
            )
        }
    }
}

@Composable
private fun ProgramCard(
    program: WorkoutProgram,
    strings: AppStrings,
    onStartDay: (WorkoutDay) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = program.nameEn,
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = TextWhite,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Text(
                        text = "${program.nameAr} • ${program.difficulty}",
                        style = MaterialTheme.typography.bodySmall.copy(color = LimeGreen)
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(LimeGreen.copy(alpha = 0.15f))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "${program.daysPerWeek}d / wk",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = LimeGreen,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = program.scheduleEn,
                style = MaterialTheme.typography.bodySmall.copy(color = TextMutedGray)
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Days sub-list
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                program.days.forEach { day ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(DarkBackground)
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = day.titleEn,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = TextWhite,
                                    fontWeight = FontWeight.SemiBold
                                )
                            )
                            Text(
                                text = "${day.exercises.size} exercises • ${day.targetMuscles.joinToString()}",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = TextMutedGray,
                                    fontSize = 11.sp
                                )
                            )
                        }

                        Button(
                            onClick = { onStartDay(day) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = LimeGreen,
                                contentColor = DarkBackground
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("start_workout_btn")
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(strings.startWorkout, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ExerciseDetailCard(
    exercise: Exercise,
    strings: AppStrings
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(exercise.iconEmoji, fontSize = 22.sp)
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = exercise.nameEn,
                            style = MaterialTheme.typography.titleSmall.copy(
                                color = TextWhite,
                                fontWeight = FontWeight.Bold
                            )
                        )
                        Text(
                            text = "${exercise.nameAr} • ${exercise.muscleGroup}",
                            style = MaterialTheme.typography.bodySmall.copy(color = LimeGreen)
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(AccentCyan.copy(alpha = 0.15f))
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "${exercise.defaultSets}×${exercise.defaultReps} | ${exercise.defaultRestSeconds}s rest",
                        style = MaterialTheme.typography.labelSmall.copy(color = AccentCyan)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = exercise.instructionsEn,
                style = MaterialTheme.typography.bodySmall.copy(color = TextMutedGray)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = exercise.instructionsAr,
                style = MaterialTheme.typography.bodySmall.copy(color = TextMutedGray, fontSize = 11.sp)
            )
        }
    }
}

@Composable
private fun ActiveWorkoutSessionDialog(
    day: WorkoutDay,
    strings: AppStrings,
    onDismiss: () -> Unit,
    onLogSet: (WorkoutLogEntity) -> Unit,
    onOpenRestTimer: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp)
                .testTag("active_workout_dialog"),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = day.titleEn,
                            style = MaterialTheme.typography.titleMedium.copy(
                                color = LimeGreen,
                                fontWeight = FontWeight.Bold
                            )
                        )
                        Text(
                            text = "Log sets, weights and reps",
                            style = MaterialTheme.typography.bodySmall.copy(color = TextMutedGray)
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = TextMutedGray)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(340.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(day.exercises) { ex ->
                        ExerciseLoggingRow(
                            exercise = ex,
                            programName = day.titleEn,
                            strings = strings,
                            onSaveSet = onLogSet,
                            onRestRequested = onOpenRestTimer
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = onDismiss,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("finish_workout_btn"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = LimeGreen,
                        contentColor = DarkBackground
                    )
                ) {
                    Text(strings.completeWorkout, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun ExerciseLoggingRow(
    exercise: Exercise,
    programName: String,
    strings: AppStrings,
    onSaveSet: (WorkoutLogEntity) -> Unit,
    onRestRequested: () -> Unit
) {
    var completedSets by remember { mutableIntStateOf(0) }
    var weightInput by remember { mutableStateOf("60") }
    var repsInput by remember { mutableStateOf("10") }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(exercise.nameEn, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text("Target: ${exercise.defaultSets}×${exercise.defaultReps}", color = AccentCyan, fontSize = 11.sp)
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = weightInput,
                    onValueChange = { weightInput = it },
                    label = { Text("Kg", color = TextMutedGray, fontSize = 10.sp) },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextWhite,
                        unfocusedTextColor = TextWhite,
                        focusedBorderColor = LimeGreen,
                        unfocusedBorderColor = DarkSurfaceHighlight
                    )
                )

                OutlinedTextField(
                    value = repsInput,
                    onValueChange = { repsInput = it },
                    label = { Text("Reps", color = TextMutedGray, fontSize = 10.sp) },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextWhite,
                        unfocusedTextColor = TextWhite,
                        focusedBorderColor = LimeGreen,
                        unfocusedBorderColor = DarkSurfaceHighlight
                    )
                )

                Button(
                    onClick = {
                        completedSets += 1
                        val weight = weightInput.toFloatOrNull() ?: 50f
                        val reps = repsInput.toIntOrNull() ?: 10
                        onSaveSet(
                            WorkoutLogEntity(
                                dateString = com.example.data.FitTrackRepository.getTodayDateString(),
                                programName = programName,
                                exerciseName = exercise.nameEn,
                                muscleGroup = exercise.muscleGroup,
                                setNumber = completedSets,
                                weightKg = weight,
                                repetitions = reps
                            )
                        )
                        // Trigger rest timer
                        onRestRequested()
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = LimeGreen,
                        contentColor = DarkBackground
                    ),
                    modifier = Modifier.height(52.dp)
                ) {
                    Text("+ Set", fontWeight = FontWeight.Bold)
                }
            }

            if (completedSets > 0) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "✓ $completedSets sets logged",
                    color = LimeGreen,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}
