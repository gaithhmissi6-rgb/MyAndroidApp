package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.UserProfileEntity
import com.example.localization.AppStrings
import com.example.localization.FitTrackStrings
import com.example.localization.Language
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentOrange
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.DarkSurfaceHighlight
import com.example.ui.theme.LimeGreen
import com.example.ui.theme.TextMutedGray
import com.example.ui.theme.TextWhite

@Composable
fun OnboardingScreen(
    initialProfile: UserProfileEntity,
    currentLanguage: Language,
    onLanguageSelected: (Language) -> Unit,
    onFinishOnboarding: (UserProfileEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    var step by remember { mutableIntStateOf(1) } // 1: Language & Name, 2: Biometrics, 3: Goals & Activity
    val strings = FitTrackStrings.get(currentLanguage)

    // Form inputs
    var name by remember { mutableStateOf(initialProfile.name) }
    var ageStr by remember { mutableStateOf(initialProfile.age.toString()) }
    var gender by remember { mutableStateOf(initialProfile.gender) }
    var heightStr by remember { mutableStateOf(initialProfile.heightCm.toInt().toString()) }
    var currentWeightStr by remember { mutableStateOf(initialProfile.currentWeightKg.toInt().toString()) }
    var targetWeightStr by remember { mutableStateOf(initialProfile.targetWeightKg.toInt().toString()) }
    var activityLevel by remember { mutableStateOf(initialProfile.activityLevel) }
    var fitnessGoal by remember { mutableStateOf(initialProfile.fitnessGoal) }
    var experienceLevel by remember { mutableStateOf(initialProfile.experienceLevel) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
            .padding(20.dp)
    ) {
        Spacer(modifier = Modifier.height(24.dp))

        // App Logo & Branding Header
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(LimeGreen),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.FitnessCenter,
                    contentDescription = null,
                    tint = DarkBackground,
                    modifier = Modifier.size(24.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = "FITTRACK",
                    style = MaterialTheme.typography.titleLarge.copy(
                        color = TextWhite,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )
                )
                Text(
                    text = "Step $step of 3",
                    style = MaterialTheme.typography.labelSmall.copy(color = LimeGreen)
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            when (step) {
                1 -> {
                    // Step 1: Language selection & Name
                    item {
                        Text(
                            text = strings.welcomeTitle,
                            style = MaterialTheme.typography.headlineSmall.copy(
                                color = TextWhite,
                                fontWeight = FontWeight.Bold
                            )
                        )
                        Text(
                            text = strings.welcomeSubtitle,
                            style = MaterialTheme.typography.bodyMedium.copy(color = TextMutedGray)
                        )
                    }

                    item {
                        Text(
                            text = strings.selectLanguage,
                            style = MaterialTheme.typography.titleSmall.copy(
                                color = LimeGreen,
                                fontWeight = FontWeight.Bold
                            )
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            LanguagePill("العربية 🇹🇳", currentLanguage == Language.ARABIC) {
                                onLanguageSelected(Language.ARABIC)
                            }
                            LanguagePill("Français 🇫🇷", currentLanguage == Language.FRENCH) {
                                onLanguageSelected(Language.FRENCH)
                            }
                            LanguagePill("English 🇺🇸", currentLanguage == Language.ENGLISH) {
                                onLanguageSelected(Language.ENGLISH)
                            }
                        }
                    }

                    item {
                        OutlinedTextField(
                            value = name,
                            onValueChange = { name = it },
                            label = { Text("Your Name / اسمك", color = TextMutedGray) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = TextWhite,
                                unfocusedTextColor = TextWhite,
                                focusedBorderColor = LimeGreen,
                                unfocusedBorderColor = DarkSurfaceHighlight
                            )
                        )
                    }

                    item {
                        Text("Gender / الجنس:", color = TextWhite, fontWeight = FontWeight.SemiBold)
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            GenderPill(strings.male, gender == "Male") { gender = "Male" }
                            GenderPill(strings.female, gender == "Female") { gender = "Female" }
                        }
                    }
                }

                2 -> {
                    // Step 2: Biometrics (Age, Height, Weight)
                    item {
                        Text(
                            text = "Biometrics & Body Stats",
                            style = MaterialTheme.typography.headlineSmall.copy(
                                color = TextWhite,
                                fontWeight = FontWeight.Bold
                            )
                        )
                        Text(
                            text = "Accurate stats allow exact BMR, TDEE, and macro calculation.",
                            style = MaterialTheme.typography.bodyMedium.copy(color = TextMutedGray)
                        )
                    }

                    item {
                        OutlinedTextField(
                            value = ageStr,
                            onValueChange = { ageStr = it },
                            label = { Text(strings.age, color = TextMutedGray) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = TextWhite,
                                unfocusedTextColor = TextWhite,
                                focusedBorderColor = LimeGreen,
                                unfocusedBorderColor = DarkSurfaceHighlight
                            )
                        )
                    }

                    item {
                        OutlinedTextField(
                            value = heightStr,
                            onValueChange = { heightStr = it },
                            label = { Text(strings.height, color = TextMutedGray) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = TextWhite,
                                unfocusedTextColor = TextWhite,
                                focusedBorderColor = LimeGreen,
                                unfocusedBorderColor = DarkSurfaceHighlight
                            )
                        )
                    }

                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            OutlinedTextField(
                                value = currentWeightStr,
                                onValueChange = { currentWeightStr = it },
                                label = { Text("${strings.currentWeight} (${strings.kgUnit})", color = TextMutedGray, fontSize = 11.sp) },
                                modifier = Modifier.weight(1f),
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = TextWhite,
                                    unfocusedTextColor = TextWhite,
                                    focusedBorderColor = LimeGreen,
                                    unfocusedBorderColor = DarkSurfaceHighlight
                                )
                            )
                            OutlinedTextField(
                                value = targetWeightStr,
                                onValueChange = { targetWeightStr = it },
                                label = { Text("${strings.targetWeight} (${strings.kgUnit})", color = TextMutedGray, fontSize = 11.sp) },
                                modifier = Modifier.weight(1f),
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = TextWhite,
                                    unfocusedTextColor = TextWhite,
                                    focusedBorderColor = LimeGreen,
                                    unfocusedBorderColor = DarkSurfaceHighlight
                                )
                            )
                        }
                    }

                    val ageNum = ageStr.toIntOrNull() ?: 24
                    if (ageNum < 18) {
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF281E05)),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text(
                                    text = "💡 ${strings.teenSafetyNotice}",
                                    color = AccentOrange,
                                    modifier = Modifier.padding(12.dp),
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                }

                3 -> {
                    // Step 3: Fitness Goal & Activity Level
                    item {
                        Text(
                            text = strings.fitnessGoal,
                            style = MaterialTheme.typography.titleMedium.copy(
                                color = TextWhite,
                                fontWeight = FontWeight.Bold
                            )
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            GoalOption(strings.muscleGain, fitnessGoal == "Muscle Gain") { fitnessGoal = "Muscle Gain" }
                            GoalOption(strings.fatLoss, fitnessGoal == "Fat Loss") { fitnessGoal = "Fat Loss" }
                            GoalOption(strings.weightMaintenance, fitnessGoal == "Weight Maintenance") { fitnessGoal = "Weight Maintenance" }
                            GoalOption(strings.weightGain, fitnessGoal == "Weight Gain") { fitnessGoal = "Weight Gain" }
                            GoalOption(strings.generalFitness, fitnessGoal == "General Fitness") { fitnessGoal = "General Fitness" }
                        }
                    }

                    item {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = strings.activityLevel,
                            style = MaterialTheme.typography.titleMedium.copy(
                                color = TextWhite,
                                fontWeight = FontWeight.Bold
                            )
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            GoalOption(strings.sedentary, activityLevel == "Sedentary") { activityLevel = "Sedentary" }
                            GoalOption(strings.lightlyActive, activityLevel == "Light") { activityLevel = "Light" }
                            GoalOption(strings.moderatelyActive, activityLevel == "Moderate") { activityLevel = "Moderate" }
                            GoalOption(strings.veryActive, activityLevel == "Very Active") { activityLevel = "Very Active" }
                        }
                    }
                }
            }
        }

        // Navigation Buttons
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (step > 1) {
                OutlinedButton(
                    onClick = { step -= 1 },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Back", color = TextWhite)
                }
            }

            Button(
                onClick = {
                    if (step < 3) {
                        step += 1
                    } else {
                        // Calculate personalized targets and finish
                        val age = ageStr.toIntOrNull() ?: 24
                        val height = heightStr.toFloatOrNull() ?: 175f
                        val currentWeight = currentWeightStr.toFloatOrNull() ?: 75f
                        val targetWeight = targetWeightStr.toFloatOrNull() ?: 72f

                        // Mifflin-St Jeor formula
                        val isMale = gender.equals("Male", ignoreCase = true)
                        val bmr = if (isMale) {
                            (10 * currentWeight) + (6.25 * height) - (5 * age) + 5
                        } else {
                            (10 * currentWeight) + (6.25 * height) - (5 * age) - 161
                        }

                        val multiplier = when (activityLevel) {
                            "Sedentary" -> 1.2
                            "Light" -> 1.375
                            "Moderate" -> 1.55
                            "Very Active" -> 1.725
                            else -> 1.9
                        }
                        val tdee = bmr * multiplier

                        val cals = when (fitnessGoal) {
                            "Muscle Gain" -> (tdee + 300).toInt()
                            "Fat Loss" -> (tdee - 450).toInt().coerceAtLeast(1400)
                            "Weight Gain" -> (tdee + 500).toInt()
                            else -> tdee.toInt()
                        }

                        val proteinG = (currentWeight * 2.0f).toInt()
                        val fatG = ((cals * 0.25) / 9).toInt()
                        val carbsG = ((cals - (proteinG * 4) - (fatG * 9)) / 4).toInt()

                        val updatedProfile = initialProfile.copy(
                            name = if (name.isNotBlank()) name else "Athlete",
                            age = age,
                            gender = gender,
                            heightCm = height,
                            currentWeightKg = currentWeight,
                            targetWeightKg = targetWeight,
                            activityLevel = activityLevel,
                            fitnessGoal = fitnessGoal,
                            experienceLevel = experienceLevel,
                            dailyCalorieTarget = cals,
                            dailyProteinTargetG = proteinG,
                            dailyCarbsTargetG = carbsG,
                            dailyFatTargetG = fatG,
                            dailyWaterTargetMl = 2800,
                            selectedLanguage = currentLanguage.code,
                            isRtl = currentLanguage.isRtl,
                            isOnboarded = true
                        )
                        onFinishOnboarding(updatedProfile)
                    }
                },
                modifier = Modifier
                    .weight(1f)
                    .testTag("onboarding_next_btn"),
                colors = ButtonDefaults.buttonColors(containerColor = LimeGreen, contentColor = DarkBackground)
            ) {
                Text(if (step < 3) strings.continueBtn else strings.getStartedBtn, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun LanguagePill(label: String, isSelected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (isSelected) LimeGreen else DarkSurfaceElevated)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Text(
            text = label,
            color = if (isSelected) DarkBackground else TextWhite,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp
        )
    }
}

@Composable
private fun GenderPill(label: String, isSelected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(if (isSelected) LimeGreen else DarkSurfaceElevated)
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 10.dp)
    ) {
        Text(
            text = label,
            color = if (isSelected) DarkBackground else TextWhite,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun GoalOption(label: String, isSelected: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(if (isSelected) DarkSurfaceHighlight else DarkSurfaceElevated)
            .clickable(onClick = onClick)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            color = if (isSelected) LimeGreen else TextWhite,
            fontWeight = FontWeight.SemiBold
        )
        if (isSelected) {
            Icon(Icons.Default.Check, contentDescription = null, tint = LimeGreen)
        }
    }
}
