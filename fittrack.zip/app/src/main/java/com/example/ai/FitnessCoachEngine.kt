package com.example.ai

import com.example.data.local.UserProfileEntity
import com.example.localization.Language

data class CoachMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val sender: String, // "user" or "coach"
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)

object FitnessCoachEngine {

    fun generateResponse(
        prompt: String,
        userProfile: UserProfileEntity,
        language: Language,
        caloriesConsumedToday: Int = 0,
        proteinConsumedToday: Float = 0f
    ): String {
        val q = prompt.lowercase().trim()

        return when (language) {
            Language.ARABIC -> generateArabicResponse(q, userProfile, caloriesConsumedToday, proteinConsumedToday)
            Language.FRENCH -> generateFrenchResponse(q, userProfile, caloriesConsumedToday, proteinConsumedToday)
            else -> generateEnglishResponse(q, userProfile, caloriesConsumedToday, proteinConsumedToday)
        }
    }

    private fun generateArabicResponse(
        q: String,
        user: UserProfileEntity,
        calsToday: Int,
        proteinToday: Float
    ): String {
        // Calculate BMR using Mifflin-St Jeor Formula
        val isMale = user.gender.equals("Male", ignoreCase = true)
        val bmr = if (isMale) {
            (10 * user.currentWeightKg) + (6.25 * user.heightCm) - (5 * user.age) + 5
        } else {
            (10 * user.currentWeightKg) + (6.25 * user.heightCm) - (5 * user.age) - 161
        }
        val activityMultiplier = when (user.activityLevel) {
            "Sedentary" -> 1.2
            "Light" -> 1.375
            "Moderate" -> 1.55
            "Very Active" -> 1.725
            else -> 1.9
        }
        val tdee = (bmr * activityMultiplier).toInt()

        if (q.contains("سعرة") || q.contains("calorie") || q.contains("سعرات") || q.contains("أحتاج")) {
            return "بناءً على قياساتك (العمر: ${user.age} سنة، الوزن: ${user.currentWeightKg} كغ، الطول: ${user.heightCm.toInt()} سم، النشاط: ${user.activityLevel}):\n\n" +
                    "• معدل الأيض الأساسي (BMR): ${bmr.toInt()} سعرة حرارية.\n" +
                    "• إجمالي استهلاك الطاقة اليومي (TDEE): $tdee سعرة حرارية.\n" +
                    "• هدفك المحدد (${user.fitnessGoal}): نوصي باستهلاك **${user.dailyCalorieTarget} سعرة حرارية يومياً**.\n" +
                    (if (user.fitnessGoal == "Muscle Gain") "مع فائض مدروس (+300 سعرة) لتعزيز البناء العضلي دون تراكم دهون."
                    else if (user.fitnessGoal == "Fat Loss") "مع عجز صحي (-400 سعرة) لتحفيز حرق الدهون مع الحفاظ على الكتلة العضلية."
                    else "للحفاظ على توازن الطاقة والوزن الحالي.")
        }

        if (q.contains("بروتين") || q.contains("protein")) {
            val minProtein = (user.currentWeightKg * 1.6f).toInt()
            val maxProtein = (user.currentWeightKg * 2.2f).toInt()
            return "كمية البروتين المثالية لك وفقاً لوزنك (${user.currentWeightKg} كغ) وهدفك (${user.fitnessGoal}):\n\n" +
                    "• المعدل العلمي الموصى به: بين $minProtein غرام إلى $maxProtein غرام يومياً (1.6 - 2.2 غ/كغ).\n" +
                    "• هدفك المسجل في التطبيق: **${user.dailyProteinTargetG} غرام بروتين**.\n" +
                    "• مصادر ممتازة: صدور الدجاج (31غ بروتين/100غ)، البيض (6غ للبيضة)، التونة المعلبة (26غ/100غ)، الكسكسي باللحم، ومخفوق الواي بروتين."
        }

        if (q.contains("عضل") || q.contains("بناء") || q.contains("muscle")) {
            return "لبناء العضلات بأقصى كفاءة وفقاً لهدف (${user.fitnessGoal}):\n\n" +
                    "1. **التدريب التدريجي (Progressive Overload):** زد الأوزان أو التكرارات تدريجياً أسبوعياً.\n" +
                    "2. **البروتين الكافي:** استهلك ${user.dailyProteinTargetG} غرام يومياً مقسمة على 3-4 وجبات.\n" +
                    "3. **فائض السعرات:** التزم بهدفك (${user.dailyCalorieTarget} سعرة حرارية).\n" +
                    "4. **النوم والتعافي:** احرص على 7-8 ساعات نوم عميق لإفراز هرمون النمو.\n" +
                    "5. **البرنامج المقترح:** نوصي بجدول دفع-سحب-أرجل (PPL) المتوفر في تبويب التمارين."
        }

        if (q.contains("زيادة وزن") || q.contains("وزني") || q.contains("gain weight")) {
            return "لزيادة وزنك بطريقة صحية وقوية:\n\n" +
                    "• ركز على الأطعمة الغنية بالسعرات النظيفة والمغذية مثل الشوفان بالحليب كامل الدسم، المكسرات (اللوز والجوز)، زبدة الفول السوداني، زيت الزيتون، والتمر.\n" +
                    "• تناول وجبة خفيفة غنية بالسعرات بين الوجبات الرئيسية.\n" +
                    "• تدرب بأوزان ثقيلة لتحويل السعرات الفائضة إلى كتلة عضلية نقية بدلاً من شحوم."
        }

        if (q.contains("وجبة") || q.contains("suggest") || q.contains("meal") || q.contains("أكل")) {
            return "إليك اقتراح وجبة متوازنة عالية البروتين مناسبة لهدفك:\n\n" +
                    "🍲 **وجبة الغداء المقترحة:**\n" +
                    "• 180 غرام صدر دجاج مشوي متبل بزيت الزيتون والأعشاب\n" +
                    "• 200 غرام أرز بسمتي أو صحن كسكسي بالخضار\n" +
                    "• سلطة خضراء مع زيت زيتون بكر\n" +
                    "• **المجموع التقريبي:** 620 سعرة، 52 غرام بروتين، 68 غرام كارب، 14 غرام دهون صحية."
        }

        if (q.contains("تحليل") || q.contains("analyze") || q.contains("تغذيتي")) {
            val rem = user.dailyCalorieTarget - calsToday
            return "تحليل تغذيتك لليوم:\n\n" +
                    "• السعرات المستهلكة اليوم: $calsToday سعرة من أصل ${user.dailyCalorieTarget} سعرة.\n" +
                    "• المتبقي لك: $rem سعرة.\n" +
                    "• البروتين المستهلك: ${proteinToday.toInt()}غ من أصل ${user.dailyProteinTargetG}غ.\n" +
                    (if (rem > 400) "نصيحة: لا تزال بحاجة إلى وجبة متكاملة غنية بالبروتين للوصول إلى هدفك اليومي وتغذية عضلاتك."
                    else "ممتاز! استمر على هذا الانضباط للوصول لهدفك.")
        }

        return "أهلاً بك! أنا مدرب FITTRACK الذكي. بصفتك تهدف إلى (${user.fitnessGoal}) بوزن ${user.currentWeightKg} كغ، يسعدني مساعدتك في حساب سعراتك، تصميم جدولك التدريبي، اقتراح وجبات غنية بالبروتين، أو شرح التمارين الرياضية. تفضل بسؤالك!"
    }

    private fun generateFrenchResponse(
        q: String,
        user: UserProfileEntity,
        calsToday: Int,
        proteinToday: Float
    ): String {
        val isMale = user.gender.equals("Male", ignoreCase = true)
        val bmr = if (isMale) {
            (10 * user.currentWeightKg) + (6.25 * user.heightCm) - (5 * user.age) + 5
        } else {
            (10 * user.currentWeightKg) + (6.25 * user.heightCm) - (5 * user.age) - 161
        }
        val tdee = (bmr * 1.55).toInt()

        if (q.contains("calorie") || q.contains("besoin") || q.contains("combien")) {
            return "D'après votre profil (${user.age} ans, ${user.currentWeightKg} kg, ${user.heightCm.toInt()} cm) :\n\n" +
                    "• Métabolisme de base (BMR) : ${bmr.toInt()} kcal.\n" +
                    "• Dépense énergétique journalière (TDEE) : $tdee kcal.\n" +
                    "• Pour votre objectif (${user.fitnessGoal}) : votre cible quotidienne est de **${user.dailyCalorieTarget} kcal**."
        }

        if (q.contains("protéine") || q.contains("protein")) {
            val minProtein = (user.currentWeightKg * 1.6f).toInt()
            val maxProtein = (user.currentWeightKg * 2.2f).toInt()
            return "Pour optimiser votre développement musculaire (${user.currentWeightKg} kg) :\n\n" +
                    "• Apport recommandé : entre $minProtein g et $maxProtein g de protéines par jour.\n" +
                    "• Votre cible personnalisée : **${user.dailyProteinTargetG} g/jour**.\n" +
                    "• Sources idéales : Poulet (31g/100g), Œufs, Thon, Couscous à la viande, Fromage blanc et Whey."
        }

        if (q.contains("muscle") || q.contains("prise de masse")) {
            return "Stratégie clé pour la prise de muscle :\n\n" +
                    "1. Surcharge progressive à chaque séance de musculation.\n" +
                    "2. Apport de ${user.dailyProteinTargetG} g de protéines par jour.\n" +
                    "3. Léger surplus calorique (${user.dailyCalorieTarget} kcal).\n" +
                    "4. Sommeil réparateur de 7 à 8 heures par nuit."
        }

        return "Bonjour ! Je suis votre coach FITTRACK. Je peux calculer vos calories, analyser vos macros, recommander des programmes d'entraînement ou vous proposer des recettes saines adaptées à votre objectif (${user.fitnessGoal}). Que souhaitez-vous savoir ?"
    }

    private fun generateEnglishResponse(
        q: String,
        user: UserProfileEntity,
        calsToday: Int,
        proteinToday: Float
    ): String {
        val isMale = user.gender.equals("Male", ignoreCase = true)
        val bmr = if (isMale) {
            (10 * user.currentWeightKg) + (6.25 * user.heightCm) - (5 * user.age) + 5
        } else {
            (10 * user.currentWeightKg) + (6.25 * user.heightCm) - (5 * user.age) - 161
        }
        val tdee = (bmr * 1.55).toInt()

        if (q.contains("calorie") || q.contains("need") || q.contains("how many")) {
            return "Based on your personal biometrics (${user.age} yrs, ${user.currentWeightKg} kg, ${user.heightCm.toInt()} cm):\n\n" +
                    "• Basal Metabolic Rate (BMR): ${bmr.toInt()} kcal.\n" +
                    "• Total Daily Energy Expenditure (TDEE): $tdee kcal.\n" +
                    "• Target for ${user.fitnessGoal}: **${user.dailyCalorieTarget} kcal/day**.\n" +
                    (if (user.fitnessGoal == "Muscle Gain") "Calculated with a clean +300 kcal surplus to maximize muscle growth."
                    else if (user.fitnessGoal == "Fat Loss") "Calculated with a moderate -400 kcal deficit to burn fat while preserving muscle."
                    else "Maintained for optimal energy balance and weight stability.")
        }

        if (q.contains("protein")) {
            val minP = (user.currentWeightKg * 1.6f).toInt()
            val maxP = (user.currentWeightKg * 2.2f).toInt()
            return "Your optimal protein intake for ${user.currentWeightKg} kg:\n\n" +
                    "• Scientific range: $minP g to $maxP g daily (1.6 - 2.2 g/kg).\n" +
                    "• Your customized target: **${user.dailyProteinTargetG} g of protein**.\n" +
                    "• Top protein sources: Chicken breast, salmon, eggs, Greek yogurt, canned tuna, and whey isolate."
        }

        if (q.contains("muscle") || q.contains("build")) {
            return "Hypertrophy Blueprint for ${user.fitnessGoal}:\n\n" +
                    "1. **Progressive Overload:** Increase resistance or repetitions over time.\n" +
                    "2. **Protein Distribution:** Hit ${user.dailyProteinTargetG}g spread across 3-4 meals.\n" +
                    "3. **Energy Fuel:** Maintain your ${user.dailyCalorieTarget} kcal target.\n" +
                    "4. **Recovery:** Aim for 7.5 to 8 hours of quality sleep.\n" +
                    "5. **Program:** Check the Push Pull Legs (PPL) or Upper/Lower routines in the Workouts tab!"
        }

        if (q.contains("meal") || q.contains("suggest") || q.contains("food")) {
            return "Recommended High-Protein Performance Meal:\n\n" +
                    "🍽️ **Grilled Chicken & Rice Recovery Bowl:**\n" +
                    "• 180g Grilled Chicken Breast\n" +
                    "• 200g Steamed Basmati Rice\n" +
                    "• 50g Sliced Avocado\n" +
                    "• Fresh leafy greens with a touch of olive oil\n" +
                    "• **Total:** 610 kcal | 54g Protein | 64g Carbs | 12g Healthy Fats"
        }

        if (q.contains("analyze") || q.contains("nutrition")) {
            val remaining = user.dailyCalorieTarget - calsToday
            return "Today's Nutrition Breakdown:\n\n" +
                    "• Calories Consumed: $calsToday / ${user.dailyCalorieTarget} kcal\n" +
                    "• Remaining: $remaining kcal\n" +
                    "• Protein Consumed: ${proteinToday.toInt()}g / ${user.dailyProteinTargetG}g\n" +
                    (if (remaining > 350) "You still have room for a nutritious high-protein meal to reach your daily goal."
                    else "You are right on track with your nutritional targets for today!")
        }

        return "Welcome! I am your FITTRACK AI Coach. Based on your goal (${user.fitnessGoal}) and stats (${user.currentWeightKg} kg), I can calculate your exact calories, macro split, workout plans, or evaluate your meals. How can I help you today?"
    }
}
