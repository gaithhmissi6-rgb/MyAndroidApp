package com.example.ai

import com.example.model.FoodCatalog
import com.example.model.FoodItem

data class ParsedFoodPortion(
    val foodItem: FoodItem,
    var quantityGramsOrMl: Float,
    val recognizedText: String = ""
) {
    val calories: Int get() = foodItem.calculateCalories(quantityGramsOrMl)
    val protein: Float get() = foodItem.calculateProtein(quantityGramsOrMl)
    val carbs: Float get() = foodItem.calculateCarbs(quantityGramsOrMl)
    val fat: Float get() = foodItem.calculateFat(quantityGramsOrMl)
}

data class ScanResult(
    val title: String,
    val items: MutableList<ParsedFoodPortion>,
    val confidence: Float = 0.94f,
    val notes: String = ""
) {
    val totalCalories: Int get() = items.sumOf { it.calories }
    val totalProtein: Float get() = items.map { it.protein }.sum()
    val totalCarbs: Float get() = items.map { it.carbs }.sum()
    val totalFat: Float get() = items.map { it.fat }.sum()
}

object FoodScannerEngine {

    /**
     * Parses freeform natural language text or voice transcript in English, Arabic, or French.
     * Examples:
     * - "3 eggs, 250 ml milk, 150 g chicken"
     * - "أكلت بيضتين، 150 غرام صدر دجاج، وموزة"
     * - "J'ai mangé deux œufs, une banane et un verre de lait"
     */
    fun parseNaturalLanguage(input: String): ScanResult {
        val parsedItems = mutableListOf<ParsedFoodPortion>()
        val text = input.lowercase().trim()

        // Match against catalog items
        FoodCatalog.items.forEach { food ->
            val matches = containsFoodReference(text, food.id)
            if (matches) {
                val quantity = extractQuantityForFood(text, food)
                parsedItems.add(
                    ParsedFoodPortion(
                        foodItem = food,
                        quantityGramsOrMl = quantity,
                        recognizedText = food.nameEn
                    )
                )
            }
        }

        // Fallback if nothing matched
        if (parsedItems.isEmpty()) {
            val best = FoodCatalog.items.firstOrNull {
                text.contains(it.nameEn.lowercase()) ||
                text.contains(it.nameAr) ||
                text.contains(it.nameFr.lowercase())
            } ?: FoodCatalog.items.first { it.id == "whole_egg" }
            parsedItems.add(ParsedFoodPortion(best, best.defaultServingGrams, "Default portion"))
        }

        return ScanResult(
            title = "Meal Analysis",
            items = parsedItems,
            notes = "Nutritional values calculated from portion analysis."
        )
    }

    private fun containsFoodReference(text: String, foodId: String): Boolean {
        return when (foodId) {
            "whole_egg" -> text.contains("egg") || text.contains("œuf") || text.contains("oeuf") ||
                    text.contains("بيض") || text.contains("عظمة") || text.contains("عظام")
            "whole_milk" -> text.contains("milk") || text.contains("lait") || text.contains("حليب")
            "chicken_breast" -> text.contains("chicken") || text.contains("poulet") || text.contains("دجاج") || text.contains("صدر")
            "banana" -> text.contains("banana") || text.contains("banane") || text.contains("موز")
            "couscous" -> text.contains("couscous") || text.contains("كسكسي")
            "brik" -> text.contains("brik") || text.contains("brick") || text.contains("بريك")
            "ojja" -> text.contains("ojja") || text.contains("عجة")
            "lablabi" -> text.contains("lablabi") || text.contains("leblebi") || text.contains("لبلابي")
            "makrouna" -> text.contains("makrouna") || text.contains("macaroni") || text.contains("مقرونة")
            "dates" -> text.contains("date") || text.contains("datte") || text.contains("تمر") || text.contains("دقلة")
            "shakshuka" -> text.contains("shakshuka") || text.contains("chakchouka") || text.contains("شكشوكة")
            "salmon" -> text.contains("salmon") || text.contains("saumon") || text.contains("سلمون")
            "tuna_canned" -> text.contains("tuna") || text.contains("thon") || text.contains("تونة") || text.contains("تن")
            "beef_steak" -> text.contains("beef") || text.contains("steak") || text.contains("لحم")
            "whey_protein" -> text.contains("protein") || text.contains("whey") || text.contains("بروتين")
            "greek_yogurt" -> text.contains("yogurt") || text.contains("yaourt") || text.contains("زبادي")
            "white_rice" -> text.contains("rice") || text.contains("riz") || text.contains("أرز") || text.contains("ارز")
            "rolled_oats" -> text.contains("oat") || text.contains("avoine") || text.contains("شوفان")
            "sweet_potato" -> text.contains("sweet potato") || text.contains("patate") || text.contains("بطاطا")
            "avocado" -> text.contains("avocado") || text.contains("avocat") || text.contains("أفوكادو")
            "olive_oil" -> text.contains("olive oil") || text.contains("huile") || text.contains("زيت")
            "almonds" -> text.contains("almond") || text.contains("amande") || text.contains("لوز")
            "emirati_machboos" -> text.contains("machboos") || text.contains("مجبوس") || text.contains("كبسة")
            "emirati_harees" -> text.contains("harees") || text.contains("هريس")
            "emirati_saloona" -> text.contains("saloona") || text.contains("صالونة")
            "emirati_balaleet" -> text.contains("balaleet") || text.contains("بلاليط")
            "emirati_luqaimat" -> text.contains("luqaimat") || text.contains("لقيمات")
            "camel_milk" -> text.contains("camel milk") || text.contains("إبل") || text.contains("نوق") || text.contains("ناقة")
            else -> false
        }
    }

    private fun extractQuantityForFood(text: String, food: FoodItem): Float {
        // Look for numbers near food keywords
        when (food.id) {
            "whole_egg" -> {
                if (text.contains("بيضتين") || text.contains("two eggs") || text.contains("2 eggs") || text.contains("deux œufs")) return 100f // 2 eggs = 100g
                if (text.contains("3 eggs") || text.contains("three eggs") || text.contains("trois œufs") || text.contains("3 بيض")) return 150f
                if (text.contains("4 eggs") || text.contains("four eggs") || text.contains("4 بيض")) return 200f
                if (text.contains("1 egg") || text.contains("one egg") || text.contains("بيضة")) return 50f
            }
            "whole_milk", "camel_milk" -> {
                if (text.contains("250")) return 250f
                if (text.contains("200")) return 200f
                if (text.contains("300")) return 300f
                if (text.contains("500")) return 500f
                if (text.contains("كوب") || text.contains("glass") || text.contains("verre")) return 250f
            }
            "chicken_breast" -> {
                if (text.contains("150")) return 150f
                if (text.contains("200")) return 200f
                if (text.contains("100")) return 100f
                if (text.contains("250")) return 250f
            }
            "white_rice" -> {
                if (text.contains("150")) return 150f
                if (text.contains("200")) return 200f
                if (text.contains("100")) return 100f
            }
            "banana" -> {
                if (text.contains("2") || text.contains("deux") || text.contains("موزتين")) return 240f
                return 120f
            }
            "brik" -> {
                if (text.contains("2") || text.contains("كعبتين")) return 240f
                return 120f
            }
        }
        return food.defaultServingGrams
    }

    /**
     * Photo recognition presets for simulated/live visual recognition of traditional & healthy meals.
     */
    val presetVisualMeals: List<ScanResult> = listOf(
        ScanResult(
            title = "Emirati Chicken Machboos Plate 🇦🇪",
            items = mutableListOf(
                ParsedFoodPortion(FoodCatalog.items.first { it.id == "emirati_machboos" }, 350f, "Emirati Saffron Machboos"),
                ParsedFoodPortion(FoodCatalog.items.first { it.id == "dates" }, 50f, "Royal Dates with Gahwa")
            ),
            confidence = 0.98f,
            notes = "Authentic Emirati saffron rice, roasted chicken & dried loomi lime."
        ),
        ScanResult(
            title = "Tunisian Couscous Plate",
            items = mutableListOf(
                ParsedFoodPortion(FoodCatalog.items.first { it.id == "couscous" }, 350f, "Couscous with Lamb & Veggies"),
                ParsedFoodPortion(FoodCatalog.items.first { it.id == "olive_oil" }, 10f, "Olive Oil Drizzle")
            ),
            confidence = 0.96f,
            notes = "Estimated ~350g portion with rich vegetable sauce and lean lamb."
        ),
        ScanResult(
            title = "Traditional Ojja & Brik Combo",
            items = mutableListOf(
                ParsedFoodPortion(FoodCatalog.items.first { it.id == "ojja" }, 280f, "Spicy Ojja Merguez"),
                ParsedFoodPortion(FoodCatalog.items.first { it.id == "brik" }, 120f, "Egg & Tuna Brik")
            ),
            confidence = 0.94f,
            notes = "Traditional savory meal rich in high quality protein."
        ),
        ScanResult(
            title = "Tunisian Chickpea Lablabi Bowl",
            items = mutableListOf(
                ParsedFoodPortion(FoodCatalog.items.first { it.id == "lablabi" }, 350f, "Lablabi with Poached Egg"),
                ParsedFoodPortion(FoodCatalog.items.first { it.id == "olive_oil" }, 15f, "Extra Virgin Olive Oil"),
                ParsedFoodPortion(FoodCatalog.items.first { it.id == "tuna_canned" }, 50f, "Tuna Topping")
            ),
            confidence = 0.95f,
            notes = "High-fiber chickpea soup with cumin, garlic and olive oil."
        ),
        ScanResult(
            title = "High-Protein Chicken & Rice Bowl",
            items = mutableListOf(
                ParsedFoodPortion(FoodCatalog.items.first { it.id == "chicken_breast" }, 180f, "Grilled Herb Chicken Breast"),
                ParsedFoodPortion(FoodCatalog.items.first { it.id == "white_rice" }, 200f, "Steamed Basmati Rice"),
                ParsedFoodPortion(FoodCatalog.items.first { it.id == "avocado" }, 50f, "Sliced Avocado")
            ),
            confidence = 0.98f,
            notes = "Clean muscle-building meal with balanced macros."
        ),
        ScanResult(
            title = "Athlete Power Breakfast",
            items = mutableListOf(
                ParsedFoodPortion(FoodCatalog.items.first { it.id == "whole_egg" }, 150f, "3 Scrambled Eggs"),
                ParsedFoodPortion(FoodCatalog.items.first { it.id == "rolled_oats" }, 60f, "Warm Oatmeal"),
                ParsedFoodPortion(FoodCatalog.items.first { it.id == "whole_milk" }, 200f, "Fresh Whole Milk"),
                ParsedFoodPortion(FoodCatalog.items.first { it.id == "banana" }, 120f, "Sliced Fresh Banana")
            ),
            confidence = 0.97f,
            notes = "Nutrient-packed energy breakfast for optimal morning fuel."
        ),
        ScanResult(
            title = "Salmon & Sweet Potato Recovery Plate",
            items = mutableListOf(
                ParsedFoodPortion(FoodCatalog.items.first { it.id == "salmon" }, 160f, "Pan-Seared Salmon"),
                ParsedFoodPortion(FoodCatalog.items.first { it.id == "sweet_potato" }, 200f, "Roasted Sweet Potato"),
                ParsedFoodPortion(FoodCatalog.items.first { it.id == "olive_oil" }, 10f, "Olive Oil Glaze")
            ),
            confidence = 0.95f,
            notes = "Omega-3 fatty acids and complex carbohydrates for workout recovery."
        )
    )
}
