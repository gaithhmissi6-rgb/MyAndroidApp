package com.example.localization

enum class Language(
    val code: String,
    val displayName: String,
    val nativeName: String,
    val isRtl: Boolean,
    val flagEmoji: String
) {
    ARABIC("ar", "Arabic", "العربية", true, "🇹🇳"),
    FRENCH("fr", "French", "Français", false, "🇫🇷"),
    ENGLISH("en", "English", "English", false, "🇺🇸"),
    GERMAN("de", "German", "Deutsch", false, "🇩🇪"),
    SPANISH("es", "Spanish", "Español", false, "🇪🇸"),
    ITALIAN("it", "Italian", "Italiano", false, "🇮🇹"),
    PORTUGUESE("pt", "Portuguese", "Português", false, "🇧🇷"),
    TURKISH("tr", "Turkish", "Türkçe", false, "🇹🇷"),
    RUSSIAN("ru", "Russian", "Русский", false, "🇷🇺"),
    CHINESE("zh", "Chinese", "中文", false, "🇨🇳"),
    JAPANESE("ja", "Japanese", "日本語", false, "🇯🇵"),
    KOREAN("ko", "Korean", "한국어", false, "🇰🇷"),
    HINDI("hi", "Hindi", "हिन्दी", false, "🇮🇳"),
    INDONESIAN("id", "Indonesian", "Bahasa Indonesia", false, "🇮🇩"),
    DUTCH("nl", "Dutch", "Nederlands", false, "🇳🇱");

    companion object {
        fun fromCode(code: String): Language {
            return entries.firstOrNull { it.code.equals(code, ignoreCase = true) } ?: ENGLISH
        }
    }
}
