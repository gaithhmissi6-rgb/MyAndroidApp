package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface FitTrackDao {

    // User Profile
    @Query("SELECT * FROM user_profile WHERE id = 1")
    fun getUserProfile(): Flow<UserProfileEntity?>

    @Query("SELECT * FROM user_profile WHERE id = 1")
    suspend fun getUserProfileSync(): UserProfileEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveUserProfile(profile: UserProfileEntity)

    // Food Logs
    @Query("SELECT * FROM food_logs WHERE dateString = :dateString ORDER BY timestamp ASC")
    fun getFoodLogsForDate(dateString: String): Flow<List<FoodLogEntity>>

    @Query("SELECT * FROM food_logs WHERE dateString BETWEEN :startDate AND :endDate ORDER BY dateString ASC")
    fun getFoodLogsInRange(startDate: String, endDate: String): Flow<List<FoodLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFoodLog(foodLog: FoodLogEntity): Long

    @Delete
    suspend fun deleteFoodLog(foodLog: FoodLogEntity)

    // Custom & Favorite Foods
    @Query("SELECT * FROM custom_foods ORDER BY isFavorite DESC, name ASC")
    fun getAllCustomFoods(): Flow<List<CustomFoodEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCustomFood(food: CustomFoodEntity): Long

    @Update
    suspend fun updateCustomFood(food: CustomFoodEntity)

    @Delete
    suspend fun deleteCustomFood(food: CustomFoodEntity)

    // Workout Logs
    @Query("SELECT * FROM workout_logs WHERE dateString = :dateString ORDER BY id ASC")
    fun getWorkoutLogsForDate(dateString: String): Flow<List<WorkoutLogEntity>>

    @Query("SELECT * FROM workout_logs ORDER BY timestamp DESC LIMIT :limit")
    fun getRecentWorkoutLogs(limit: Int = 100): Flow<List<WorkoutLogEntity>>

    @Query("SELECT DISTINCT dateString FROM workout_logs WHERE dateString >= :sinceDate")
    fun getWorkoutDatesSince(sinceDate: String): Flow<List<String>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWorkoutLog(log: WorkoutLogEntity): Long

    @Delete
    suspend fun deleteWorkoutLog(log: WorkoutLogEntity)

    // Body Measurements & Weight Progress
    @Query("SELECT * FROM body_measurements ORDER BY dateString ASC")
    fun getAllBodyMeasurements(): Flow<List<BodyMeasurementEntity>>

    @Query("SELECT * FROM body_measurements ORDER BY dateString DESC LIMIT 1")
    fun getLatestBodyMeasurement(): Flow<BodyMeasurementEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBodyMeasurement(measurement: BodyMeasurementEntity): Long

    @Delete
    suspend fun deleteBodyMeasurement(measurement: BodyMeasurementEntity)

    // Water Logs
    @Query("SELECT * FROM water_logs WHERE dateString = :dateString")
    fun getWaterLog(dateString: String): Flow<WaterLogEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun setWaterLog(waterLog: WaterLogEntity)

    // Sleep Logs
    @Query("SELECT * FROM sleep_logs WHERE dateString = :dateString")
    fun getSleepLog(dateString: String): Flow<SleepLogEntity?>

    @Query("SELECT * FROM sleep_logs ORDER BY dateString DESC LIMIT 7")
    fun getRecentSleepLogs(): Flow<List<SleepLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun setSleepLog(sleepLog: SleepLogEntity)
}
