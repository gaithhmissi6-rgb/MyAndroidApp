package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_profile")
data class UserProfileEntity(
    @PrimaryKey val id: Int = 1,
    val name: String = "Athlete",
    val age: Int = 25,
    val gender: String = "Male", // "Male", "Female", "Other"
    val heightCm: Float = 175f,
    val currentWeightKg: Float = 75f,
    val targetWeightKg: Float = 72f,
    val activityLevel: String = "Moderate", // "Sedentary", "Light", "Moderate", "Very Active", "Extra Active"
    val fitnessGoal: String = "Muscle Gain", // "Muscle Gain", "Fat Loss", "Weight Maintenance", "Weight Gain", "General Fitness"
    val experienceLevel: String = "Intermediate", // "Beginner", "Intermediate", "Advanced"
    val dailyCalorieTarget: Int = 2300,
    val dailyProteinTargetG: Int = 150,
    val dailyCarbsTargetG: Int = 260,
    val dailyFatTargetG: Int = 65,
    val dailyWaterTargetMl: Int = 2500,
    val selectedLanguage: String = "en", // "en", "ar", "fr", etc.
    val isRtl: Boolean = false,
    val isOnboarded: Boolean = false
)

@Entity(tableName = "food_logs")
data class FoodLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val dateString: String, // "YYYY-MM-DD"
    val mealType: String, // "BREAKFAST", "LUNCH", "DINNER", "SNACK"
    val foodName: String,
    val foodNameAr: String = "",
    val foodNameFr: String = "",
    val amountGramsOrMl: Float,
    val unit: String = "g", // "g", "ml", "unit"
    val calories: Int,
    val proteinGrams: Float,
    val carbsGrams: Float,
    val fatGrams: Float,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "custom_foods")
data class CustomFoodEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val caloriesPer100g: Int,
    val proteinPer100g: Float,
    val carbsPer100g: Float,
    val fatPer100g: Float,
    val defaultServingGrams: Float = 100f,
    val isFavorite: Boolean = false
)

@Entity(tableName = "workout_logs")
data class WorkoutLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val dateString: String, // "YYYY-MM-DD"
    val programName: String, // e.g. "Push Pull Legs - Push Day"
    val exerciseName: String,
    val muscleGroup: String,
    val setNumber: Int,
    val weightKg: Float,
    val repetitions: Int,
    val completed: Boolean = true,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "body_measurements")
data class BodyMeasurementEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val dateString: String,
    val weightKg: Float,
    val chestCm: Float? = null,
    val armCm: Float? = null,
    val waistCm: Float? = null,
    val thighCm: Float? = null,
    val calfCm: Float? = null,
    val photoNote: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "water_logs")
data class WaterLogEntity(
    @PrimaryKey val dateString: String, // "YYYY-MM-DD"
    val amountMl: Int,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "sleep_logs")
data class SleepLogEntity(
    @PrimaryKey val dateString: String, // "YYYY-MM-DD"
    val durationHours: Float,
    val qualityScore: Int = 80, // 0-100
    val timestamp: Long = System.currentTimeMillis()
)
