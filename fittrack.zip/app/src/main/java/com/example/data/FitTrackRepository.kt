package com.example.data

import com.example.data.local.BodyMeasurementEntity
import com.example.data.local.CustomFoodEntity
import com.example.data.local.FitTrackDao
import com.example.data.local.FoodLogEntity
import com.example.data.local.SleepLogEntity
import com.example.data.local.UserProfileEntity
import com.example.data.local.WaterLogEntity
import com.example.data.local.WorkoutLogEntity
import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class FitTrackRepository(private val dao: FitTrackDao) {

    companion object {
        fun getTodayDateString(): String {
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            return sdf.format(Date())
        }
    }

    // User Profile
    val userProfile: Flow<UserProfileEntity?> = dao.getUserProfile()

    suspend fun getUserProfileSync(): UserProfileEntity? = dao.getUserProfileSync()

    suspend fun saveUserProfile(profile: UserProfileEntity) {
        dao.saveUserProfile(profile)
    }

    // Food Logs
    fun getTodayFoodLogs(): Flow<List<FoodLogEntity>> =
        dao.getFoodLogsForDate(getTodayDateString())

    fun getFoodLogsForDate(dateStr: String): Flow<List<FoodLogEntity>> =
        dao.getFoodLogsForDate(dateStr)

    suspend fun addFoodLog(log: FoodLogEntity) = dao.insertFoodLog(log)

    suspend fun removeFoodLog(log: FoodLogEntity) = dao.deleteFoodLog(log)

    // Custom Foods
    val customFoods: Flow<List<CustomFoodEntity>> = dao.getAllCustomFoods()

    suspend fun saveCustomFood(food: CustomFoodEntity) = dao.insertCustomFood(food)

    // Workout Logs
    fun getTodayWorkoutLogs(): Flow<List<WorkoutLogEntity>> =
        dao.getWorkoutLogsForDate(getTodayDateString())

    val recentWorkouts: Flow<List<WorkoutLogEntity>> = dao.getRecentWorkoutLogs(100)

    suspend fun logWorkoutSet(log: WorkoutLogEntity) = dao.insertWorkoutLog(log)

    // Measurements & Weight
    val allMeasurements: Flow<List<BodyMeasurementEntity>> = dao.getAllBodyMeasurements()
    val latestMeasurement: Flow<BodyMeasurementEntity?> = dao.getLatestBodyMeasurement()

    suspend fun addMeasurement(measurement: BodyMeasurementEntity) =
        dao.insertBodyMeasurement(measurement)

    // Water
    fun getTodayWaterLog(): Flow<WaterLogEntity?> = dao.getWaterLog(getTodayDateString())

    suspend fun addWaterMl(additionalMl: Int) {
        val today = getTodayDateString()
        // We'll update the water log
        dao.setWaterLog(
            WaterLogEntity(
                dateString = today,
                amountMl = additionalMl
            )
        )
    }

    suspend fun setTodayWaterAmount(totalMl: Int) {
        dao.setWaterLog(
            WaterLogEntity(
                dateString = getTodayDateString(),
                amountMl = totalMl
            )
        )
    }

    // Sleep
    fun getTodaySleepLog(): Flow<SleepLogEntity?> = dao.getSleepLog(getTodayDateString())

    suspend fun logSleep(hours: Float, quality: Int) {
        dao.setSleepLog(
            SleepLogEntity(
                dateString = getTodayDateString(),
                durationHours = hours,
                qualityScore = quality
            )
        )
    }

    suspend fun ensureDefaultUser() {
        val existing = dao.getUserProfileSync()
        if (existing == null) {
            val defaultUser = UserProfileEntity(
                id = 1,
                name = "Champion",
                age = 24,
                gender = "Male",
                heightCm = 178f,
                currentWeightKg = 76f,
                targetWeightKg = 73f,
                activityLevel = "Moderate",
                fitnessGoal = "Muscle Gain",
                experienceLevel = "Intermediate",
                dailyCalorieTarget = 2400,
                dailyProteinTargetG = 160,
                dailyCarbsTargetG = 270,
                dailyFatTargetG = 65,
                dailyWaterTargetMl = 2800,
                selectedLanguage = "en",
                isRtl = false,
                isOnboarded = true
            )
            dao.saveUserProfile(defaultUser)

            // Seed initial weight record
            dao.insertBodyMeasurement(
                BodyMeasurementEntity(
                    dateString = getTodayDateString(),
                    weightKg = 76f,
                    waistCm = 82f,
                    chestCm = 102f,
                    armCm = 37f,
                    thighCm = 58f,
                    calfCm = 38f,
                    photoNote = "Starting journey baseline"
                )
            )

            // Seed sample nutritious meal
            dao.insertFoodLog(
                FoodLogEntity(
                    dateString = getTodayDateString(),
                    mealType = "BREAKFAST",
                    foodName = "3 Scrambled Eggs & Warm Oatmeal",
                    foodNameAr = "3 بيضات مخفوقة مع شوفان دافئ",
                    foodNameFr = "3 Œufs Brouillés et Flocons d'Avoine",
                    amountGramsOrMl = 220f,
                    calories = 420,
                    proteinGrams = 28f,
                    carbsGrams = 45f,
                    fatGrams = 14f
                )
            )
        }
    }
}
